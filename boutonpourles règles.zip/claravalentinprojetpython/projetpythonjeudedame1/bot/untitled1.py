#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 17 23:18:04 2021

@author: valentinmerault
"""

def afficher(M):
    """
    Affiche une matrice en respectant les alignements par colonnes.
    Peut être utilisé pour observer la matrice à chaque nouvelle action.

    """
    w = [max([len(str(M[i][j])) for i in range(len(M))]) for j in range(len(M[0]))]
    for i in range(len(M)):
        for j in range(len(M[0])):
            print("%*s" % (w[j], str(M[i][j])), end=' ')
        print()


def matriceNulle(n, p):
    "Constructeur de matrice de dimensions données"
    M=[]
    for i in range(n):
        L=[]
        for j in range(p):
            L.append(10)
        M.append(L)
    return M

def creation_plateau(n):
    M = matriceNulle(n, n)
    
    for i in range(1,n-1):

        for j in range(1,n-1):

            if (i + j) % 2 == 0:
                M[i][j] = 0
            else:
                M[i][j] = 1
    
    
    for i in range(1,5):

        for j in range(1,n-1):
            if M[i][j] == 1:
                M[i][j] = 3

        for o in range(7, n-1):

            for p in range(1,n-1):

                if M[o][p] == 1:
                    M[o][p] = 2




    return M


M = creation_plateau(12)
afficher(M)


i = 5
j =2

alt = 0

def f():
    if alt%2==0:
        M[i][j] =2
        M[i+1][j+1] = 5
            
        if ((M[i+1][j+1]==3) and (M[i+2][j+2]==1)):
              M[i+1][j+1]=1
              
        elif ((M[i+1][j-1]==3) and (M[i+2][j-2]==1)):
               M[i+1][j-1]=1
    
    else:
          M[i][j] =3
          if ((M[i-1][j+1]==2)  and (M[i-2][j+2]==1)):
              M[i-1][j+1]=1
          elif ((M[i-1][j-1]==2) and(M[i-2][j-2]==1)):
              M[i-1][j-1]=1
   




    
