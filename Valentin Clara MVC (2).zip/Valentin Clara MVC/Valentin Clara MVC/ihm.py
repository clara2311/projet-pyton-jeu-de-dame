#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 10 10:32:49 2021

@author: clara

PARTIE GRAPHIQUE 
"""

from tkinter import Button, Label

from datas import *

global alt
alt = 0

global autorisation
autorisation =0


def interface():
    global autorisation
    autorisation = 1

def menu():
    global autorisation
    autorisation = 0

    

def caseBlanche(i, j, tk, caseB):
    button = Button(tk, image=caseB, width=70, height=72)
    button.grid(column=j, row=i)


def caseNoire(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, jeudameMenu, p, app):
    global alt
    button = Button(fen, image=caseN,
                    command=lambda: [sicaseN(i, j, M, alt,p,app), affichage(M, n, fen, pionNoir, pionBlanc, caseB, caseN,jeudameMenu, p,app)]
                    , width=70, height=72)
    button.grid(column=j, row=i)


def pionN(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, jeudameMenu, p, app):
    button = Button(fen, image=pionNoir,
                    command=lambda: [sinoir(i, j, M),affichage(M, n, fen, pionNoir, pionBlanc, caseB, caseN, jeudameMenu, p,app)]
                    , width=70, height=72)
    button.grid(column=j, row=i)


def pionB(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, jeudameMenu, p, app):
    button = Button(fen, image=pionBlanc,
                    command=lambda: [siblanc(i, j, M), affichage(M, n, fen, pionNoir, pionBlanc, caseB, caseN, jeudameMenu, p,app)]
                    , width=70, height=72)
    button.grid(column=j, row=i)


def affichage(M, n, fen, pionNoir, pionBlanc, caseB, caseN, jeudameMenu, p,app):
    global alt, autorisation
   
    if autorisation == 1:

        for c in fen.winfo_children():
            c.destroy()
    
        for i in range(n):
    
            for j in range(n):
    
                if M[i][j] == 0:
                    caseBlanche(i, j, fen, caseB)
                elif M[i][j] == 1:
                    caseNoire(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, jeudameMenu, p, app)
                elif M[i][j] == 3:
                    pionN(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, jeudameMenu, p, app)
                else:
                    pionB(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, jeudameMenu, p, app)
    
        button = Button(fen, text="Fin de Tour", command=tour, fg="black", bg="brown")
        button.grid(column=11, row=0)
    
        button_reset = Button(fen, text="Restart", command= lambda : [remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN, jeudameMenu, p, app)], fg="black", bg="brown")
        button_reset.grid(column=11, row=1)
        
        button_menu = Button(fen, text="Menu", command = lambda:[menu(),affichage(M, n, fen, pionNoir, pionBlanc, caseB, caseN, jeudameMenu, p,app)], fg="black", bg="brown")
        button_menu.grid(column=11, row=3)

         
    elif autorisation == 0:
        for c in fen.winfo_children():
            c.destroy()
         
       
         
        prenom=Label(fen, text="Merault Valentin",bg = "#E9D7A6", fg="brown", font="Ubuntu 15")
        prenom.pack(padx=0, pady=0, side='left') 
        
        mainTitre = Label(fen, text = "Bienvenue", bg = "#E9D7A6", fg="brown", font="Ubuntu 30")
        mainTitre.pack(padx=0, pady=30)
       
        button=Button(fen, image=jeudameMenu,  width=399, height=408)
        button.pack(padx=100, pady=10)
       
        
        button_start = Button(fen,fg="brown", text ="Partie locale",command = lambda:[interface(),affichage(M, n, fen, pionNoir, pionBlanc, caseB, caseN,jeudameMenu,p,app)], bg ="ivory")
        button_start.pack(padx=5,pady=5)
        
        button_BOT = Button(fen,fg="brown" ,text ="Partie vs ordinateur",command = lambda:[interface(),affichage(M, n, fen, pionNoir, pionBlanc, caseB, caseN,jeudameMenu,p,app)], bg ="ivory")
        button_BOT.pack(padx=5,pady=5)
        
        button_ONLINE = Button(fen,fg="brown", text ="Partie en ligne",command = lambda:[interface(),affichage(M, n, fen, pionNoir, pionBlanc, caseB, caseN,jeudameMenu,p,app)], bg ="ivory")
        button_ONLINE.pack(padx=5,pady=5)
        
       
        
       


def remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN,jeudameMenu,p,app):
    global alt
    MsgBox = messagebox.askquestion(title=None, message="Voulez vous vraiment recommencer la partie ?")
    if MsgBox == 'yes':
        for c in fen.winfo_children():
            c.destroy()

        M = creation_plateau(10)

        affichage(M, n, fen, pionNoir, pionBlanc, caseB, caseN,jeudameMenu,p,app)

        alt = 0
    else:
        pass

def tour():
    global alt
    alt += 1
    print(alt)

