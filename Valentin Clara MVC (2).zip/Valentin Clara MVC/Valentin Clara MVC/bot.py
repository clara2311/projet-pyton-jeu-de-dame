#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 10 22:52:40 2021

@author: valentinmerault
"""
from random import randint

def afficher(M):
    """
    Affiche une matrice en respectant les alignements par colonnes.
    Peut être utilisé pour observer la matrice à chaque nouvelle action.

    """
    w = [max([len(str(M[i][j])) for i in range(len(M))]) for j in range(len(M[0]))]
    for i in range(len(M)):
        for j in range(len(M[0])):
            print("%*s" % (w[j], str(M[i][j])), end=' ')
        print()


def matriceNulle(n, p):
    "Constructeur de matrice de dimensions données"
    M=[]
    for i in range(n):
        L=[]
        for j in range(p):
            L.append(0)
        M.append(L)
    return M

def creation_plateau(n):
    M = matriceNulle(n, n)

    for i in range(n):

        for j in range(n):

            if (i + j) % 2 == 0:
                M[i][j] = 0
            else:
                M[i][j] = 1

    for i in range(4):
        for i in range(4):

            for j in range(n):
                if M[i][j] == 1:
                    M[i][j] = 3

        for o in range(6, n):

            for p in range(n):

                if M[o][p] == 1:
                    M[o][p] = 2


    return M

M = creation_plateau(10)
afficher(M)

prePleine = True

for j in range(1,10):
    
    if M[3][j] == 1:
        print( M[3][j])
        prePleine = False
        

if prePleine ==False:
    print("la ligne n'est pas complete")
else:
    print("la ligne est complete")
    
rnd =[-1,1]
    
if prePleine==True:
    nbr = randint(0,10)
    if nbr%2 !=0:
        d=randint(0,1)
        nbr += rnd[d]

l = 3
print(nbr)
M[l][nbr] = 1
M[l+1][nbr-1] = 3
    
    
print()
afficher(M)
