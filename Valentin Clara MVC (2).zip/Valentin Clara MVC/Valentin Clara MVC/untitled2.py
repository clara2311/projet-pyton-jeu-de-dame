#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 11 00:29:44 2021

@author: valentinmerault
"""

def afficher(M):
    """
    Affiche une matrice en respectant les alignements par colonnes.
    Peut être utilisé pour observer la matrice à chaque nouvelle action.

    """
    w = [max([len(str(M[i][j])) for i in range(len(M))]) for j in range(len(M[0]))]
    for i in range(len(M)):
        for j in range(len(M[0])):
            print("%*s" % (w[j], str(M[i][j])), end=' ')
        print()


def matriceNulle(n, p):
    "Constructeur de matrice de dimensions données"
    M=[]
    for i in range(n):
        L=[]
        for j in range(p):
            L.append(0)
        M.append(L)
    return M

def creation_plateau(n):
    M = matriceNulle(n, n)

    for i in range(n):

        for j in range(n):

            if (i + j) % 2 == 0:
                M[i][j] = 0
            else:
                M[i][j] = 1

    for i in range(4):
        for i in range(4):

            for j in range(n):
                if M[i][j] == 1:
                    M[i][j] = 3

        for o in range(6, n):

            for p in range(n):

                if M[o][p] == 1:
                    M[o][p] = 2


    return M

M = creation_plateau(10)

afficher(M)

M[5][2] = 2
M[4][3] = 3
M[3][4] = 1
print()



afficher(M)

