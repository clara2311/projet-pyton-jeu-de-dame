#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 12 16:18:04 2021

@author: valentinmerault
"""

from tkinter import Tk, PhotoImage
from datas import *
from ihm import Local,menu, BOTMODE
from timeit import default_timer


import pygame
pygame.mixer.init()
p = pygame.mixer.Sound('audio/pion.wav')
app = pygame.mixer.Sound('audio/applaud.wav')
pygame.mixer.music.load('audio/Jaunter-Reset.ogg')
pygame.mixer.music.set_volume(0)
pygame.mixer.music.play(-1)


# Variables GLOBALE :
SIZE= 700
n = 12


start = default_timer()

fen = Tk()

fen.title("Jeu de Dame")
fen.iconbitmap('images/dame.ico')
fen.geometry("900x850")
fen.resizable(False, False) # Dimension de la fenêtre fixe.
fen.configure(bg="#E9D7A6")

pionNoir = PhotoImage(file = "images/pionNoir.png")
pionBlanc = PhotoImage(file = "images/pionBlanc.png")
pionDame = PhotoImage(file = "images/pionDB.png")
pionDame2 = PhotoImage(file = "images/pionDN.png")
caseB = PhotoImage(file = "images/caseB.png")
caseN = PhotoImage(file = "images/caseN.png")
jeudameMenu= PhotoImage(file = "images/jeudameMenu.png")



# Lance le jeu : 


M = creation_plateau(n)
menu(M, n, fen, pionNoir, pionBlanc, caseB, caseN,p,app,jeudameMenu,pionDame,pionDame2)
   

fen.mainloop()
fen.protocol("WM_DELETE_WINDOW", on_closing(fen))

