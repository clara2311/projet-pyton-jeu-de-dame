#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 12 16:18:34 2021

@author: valentinmerault
"""

from tkinter import Button, Label, Toplevel

from datas import *


global alt
alt = 0

global autorisation
autorisation = 0

global mode
mode = 0

def create_windows(fen):  # CLARA FAUT REMPLIR DANS CETTE FONCTION
    window = Toplevel(fen)

    window.geometry("400x600")
    window.resizable(False, False)  # Dimension de la fenêtre fixe.
    window.configure(bg="#E9D7A6")
    window.title("Jeu de Dame")
    title = Label(window, text = "Mettre les Règles", bg ="#E9D7A6" )
    title.grid(column = 4, row = 1)


def interface():
    global autorisation
    autorisation = 1


def MEN():
    global autorisation
    autorisation = 0


def mode_bot():
    global autorisation
    autorisation = 2


def reset(fen):
    for c in fen.winfo_children():
        c.destroy()


def caseBlanche(i, j, tk, caseB):
    button = Button(tk, image=caseB, width=70, height=72)
    button.grid(column=j, row=i)


def caseNoire(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2):
    global alt
    button = Button(fen, image=caseN,
                    command=lambda: [sicaseN(i, j, M, alt, p, app),
                                     Local(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame,
                                           pionDame2)]
                    , width=70, height=72)
    button.grid(column=j, row=i)


def caseBOT(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2):
    global alt
    button = Button(fen, image=caseN,
                    command=lambda: [sicaseN(i, j, M, alt, p, app),
                                     BOTMODE(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu,
                                             pionDame, pionDame2)]
                    , width=70, height=72)
    button.grid(column=j, row=i)


def pionN(i, j, fen ,M, pionNoir):
    button = Button(fen, image=pionNoir,
                    command=lambda: [sinoir(i, j, M)]
                    , width=70, height=72)
    button.grid(column=j, row=i)


def pionB(i, j, fen, pionBlanc, M):
    button = Button(fen, image=pionBlanc,
                    command=lambda: [siblanc(i, j, M)]
                    , width=70, height=72)
    button.grid(column=j, row=i)


def dameB(i, j, fen, M, pionDame):
    button = Button(fen, image=pionDame,
                    command=lambda: [siblanc(i, j, M)]
                    , width=70, height=72)
    button.grid(column=j, row=i)


def dameN(i, j, fen, M, pionDame2):
    button = Button(fen, image=pionDame2,
                    command=lambda: [sinoir(i, j, M)]
                    , width=70, height=72)
    button.grid(column=j, row=i)


def menu(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2):
    M = creation_plateau(12)

    reset(fen)

    mainTitre = Label(fen, text="Bienvenue", fg="brown", bg="#E9D7A6", font="Ubuntu 30")
    mainTitre.pack(padx=0, pady=30)

    button = Button(fen, image=jeudameMenu, width=400, height=408)
    button.pack(padx=100, pady=10)


    button_start = Button(fen, text="Partie locale", fg="brown", bg="ivory", command=lambda: [interface(),
                                                                                              Local(M, n, fen, pionNoir,
                                                                                                    pionBlanc, caseB,
                                                                                                    caseN, p,
                                                                                                    app, jeudameMenu,
                                                                                                    pionDame,
                                                                                                    pionDame2)])
    button_start.pack(padx=5, pady=5)

    button_BOT = Button(fen, text="Partie vs l'ordinateur (En développement)", fg="brown", bg="ivory",
                        command=lambda: [mode_bot(),
                                         BOTMODE(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu,
                                                 pionDame, pionDame2)]
                        )
    button_BOT.pack(padx=5, pady=5)

    button_ONLINE = Button(fen, text="Partie en ligne", fg="brown", bg="ivory", command=lambda: [interface(),
                                                                                                 Local(M, n, fen,
                                                                                                       pionNoir,
                                                                                                       pionBlanc, caseB,
                                                                                                       caseN,
                                                                                                       p, app,
                                                                                                       jeudameMenu,
                                                                                                       pionDame,
                                                                                                       pionDame2)])
    button_ONLINE.pack(padx=5, pady=5)


def Local(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2):
    global alt, autorisation, lab_player

    reset(fen)

    for i in range(1, n - 1):

        for j in range(1, n - 1):

            if M[i][j] == 0:
                caseBlanche(i, j, fen, caseB)
            elif (M[i][j] == 1) or (M[i][j] == 5) or (M[i][j] == 6):
                caseNoire(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2)
            elif M[i][j] == 3:
                pionN(i, j, fen, M, pionNoir)
            elif M[i][j] == 7:
                dameB(i, j, fen, M,pionDame)
            elif M[i][j] == 8:
                dameN(i, j, fen, M, pionDame2)
            else:
                pionB(i, j, fen, pionBlanc, M)
    print()
    afficher(M)

    button = Button(fen, text="Fin de Tour", command=lambda: [tour(),
                                                              Local(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p,
                                                                    app, jeudameMenu, pionDame, pionDame2)], fg="brown",
                    bg="ivory")
    button.grid(column=11, row=2)

    button_Regle = Button(fen, text = "RÈGLES", fg = "brown", bg = "ivory" ,command =lambda:[create_windows(fen)])
    button_Regle.grid(column = 11, row = 6)

    button_reset = Button(fen, text="Restart", command=lambda: [
        remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, lab_player, pionDame, pionDame2)],
                          fg="brown", bg="ivory")
    button_reset.grid(column=11, row=4)

    button_menu = Button(fen, text="Menu", command=lambda: [
        remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, lab_player, pionDame, pionDame2),
        MEN(), menu(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2)],
                         fg="brown", bg="ivory")
    button_menu.grid(column=11, row=5)

    button_chev = Button(fen, text="CHEVAUCHER", command=lambda: [chevauchement()], fg="red", bg="ivory")
    button_chev.grid(column=11, row=3)

    lab_player = Label(fen, text="À toi :\n Blanc", fg="brown", bg="#E9D7A6", font="Ubuntu 15")
    lab_player.grid(column=11, row=1)

    if alt % 2 == 0:
        lab_player['text'] = "À toi :\n Blanc "
    else:
        lab_player['text'] = "À toi :\n Noir "


def BOTMODE(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2):
    global alt, autorisation, mode

    alt = 0
    reset(fen)

    for i in range(1, n - 1):

        for j in range(1, n - 1):

            if M[i][j] == 0:
                caseBlanche(i, j, fen, caseB)
            elif (M[i][j] == 1) or (M[i][j] == 5) or (M[i][j] == 6):
                caseBOT(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2)
            elif M[i][j] == 3:
                pionN(i, j, fen, M, pionNoir)
            elif M[i][j] == 7:
                dameB(i, j, fen, M, pionDame)
            elif M[i][j] == 8:
                dameN(i, j, fen, M, pionDame2)
            else:
                pionB(i, j, fen, pionBlanc, M)

    button = Button(fen, text="Fin de Tour", command=lambda: [tour(), prisePionBOT(M),
                                                              BOTMODE(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p,
                                                                      app, jeudameMenu, pionDame, pionDame2)],
                    fg="brown", bg="ivory")
    button.grid(column=11, row=2)

    button_reset = Button(fen, text="Restart", command=lambda: [
        remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, lab_player, pionDame, pionDame2)],
                          fg="brown", bg="ivory")
    button_reset.grid(column=11, row=3)

    button_menu = Button(fen, text="Menu", command=lambda: [
        remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, lab_player, pionDame, pionDame2),
        MEN(), menu(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2)],
                         fg="brown", bg="ivory")
    button_menu.grid(column=11, row=4)

    lab_player = Label(fen, text="A ", fg="brown", bg="#E9D7A6", font="Ubuntu 15")


def remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, lab_player, pionDame, pionDame2):
    global alt, autorisation
    MsgBox = messagebox.askquestion(title=None, message="Voulez vous vraiment recommencer/quitter la partie ?")
    if MsgBox == 'yes':
        for c in fen.winfo_children():
            c.destroy()

        M = creation_plateau(n)
        alt = 0

        if (autorisation == 1):
            Local(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2)
        else:
            BOTMODE(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2)


    else:
        pass


def tour():
    global alt

    alt += 1
