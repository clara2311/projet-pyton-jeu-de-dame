#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 12 16:18:34 2021

@author: valentinmerault
"""

from tkinter import Button, Label

from datas import *

global alt
alt = 0

global autorisation
autorisation =0

global mode
mode =0


def interface():
    global autorisation
    autorisation = 1

def MEN():
    global autorisation
    autorisation = 0
    
def mode_bot():
    global autorisation
    autorisation = 2


def reset(fen):
    
    for c in fen.winfo_children():
        c.destroy()
        
    

def caseBlanche(i, j, tk, caseB):
    button = Button(tk, image=caseB, width=70, height=72)
    button.grid(column=j, row=i)


def caseNoire(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, p, app,jeudameMenu):
    global alt
    button = Button(fen, image=caseN,
                    command=lambda: [sicaseN(i, j, M, alt,p,app), Local(M, n, fen, pionNoir, pionBlanc, caseB, caseN,p,app,jeudameMenu)]
                    , width=70, height=72)
    button.grid(column=j, row=i)


def pionN(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, p, app,jeudameMenu):
    button = Button(fen, image=pionNoir,
                    command=lambda: [sinoir(i, j, M)]
                    , width=70, height=72)
    button.grid(column=j, row=i)


def pionB(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, p, app,jeudameMenu):
    button = Button(fen, image=pionBlanc,
                    command=lambda: [siblanc(i, j, M)]
                    , width=70, height=72)
    button.grid(column=j, row=i)


def menu(M, n, fen, pionNoir, pionBlanc, caseB, caseN,p,app,jeudameMenu):
    M = creation_plateau(10)
    
    reset(fen)
    
    mainTitre = Label(fen, text = "Bienvenue",  fg="brown", bg="#E9D7A6", font="Ubuntu 30")
    mainTitre.pack(padx=0, pady=30)
    
    
    button=Button(fen, image=jeudameMenu,  width=399, height=408)
    button.pack(padx=100, pady=10)
       
       
    button_start = Button(fen, text="Partie locale", fg="brown", bg="ivory", command=lambda: [interface(),
                                                                                     Local(M, n, fen, pionNoir,
                                                                                               pionBlanc, caseB, caseN, p,
                                                                                               app,jeudameMenu)])
    button_start.pack(padx=5,pady=5)

    button_BOT = Button(fen, text="Partie vs l'ordinateur",  fg="brown", bg="ivory",command=lambda: [mode_bot(),BOTMODE(M, n, fen, pionNoir, pionBlanc, caseB, caseN,p,app,jeudameMenu)]
                            )
    button_BOT.pack(padx=5,pady=5)

    button_ONLINE = Button(fen, text="Partie en ligne", fg="brown", bg="ivory",command=lambda: [interface(),
                                                                                        Local(M, n, fen, pionNoir,
                                                                                                  pionBlanc, caseB, caseN,
                                                                                                  p, app,jeudameMenu)])
    button_ONLINE.pack(padx=5,pady=5)

def Local(M, n, fen, pionNoir, pionBlanc, caseB, caseN,p,app,jeudameMenu):
    global alt, autorisation, mode, lab_player


    reset(fen)

 
    for i in range(n):

        for j in range(n):

            if M[i][j] == 0:
                caseBlanche(i, j, fen, caseB)
            elif M[i][j] == 1:
                caseNoire(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, p, app,jeudameMenu)
            elif M[i][j] == 3:
                pionN(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, p, app,jeudameMenu)
            else:
                pionB(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN,p, app,jeudameMenu)



    button = Button(fen, text="Fin de Tour", command=lambda:[tour()], fg="brown", bg="ivory")
    button.grid(column=11, row=0)

    button_reset = Button(fen, text="Restart", command= lambda : [remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN, p, app,jeudameMenu)],  fg="brown", bg="ivory")
    button_reset.grid(column=11, row=2)

    button_menu = Button(fen, text="Menu", command = lambda:[remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN,p,app,jeudameMenu),MEN(),menu(M, n, fen, pionNoir, pionBlanc, caseB, caseN,p,app,jeudameMenu)], fg="brown", bg="ivory")
    button_menu.grid(column=11, row=3)
    
   
    lab_player = Label(fen, text = "A toi : ",  fg="brown", bg="#E9D7A6", font="Ubuntu 15")
    lab_player.grid(column=11, row=1)
  
                

def BOTMODE(M, n, fen, pionNoir, pionBlanc, caseB, caseN,p,app,jeudameMenu):
    global alt, autorisation, mode


    reset(fen)

    for i in range(n):

        for j in range(n):

            if M[i][j] == 0:
                caseBlanche(i, j, fen, caseB)
            elif M[i][j] == 1:
                caseNoire(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, p, app,jeudameMenu)
            elif M[i][j] == 3:
                pionN(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, p, app,jeudameMenu)
            else:
                pionB(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN,p, app,jeudameMenu)



    button = Button(fen, text="Fin de Tour", command=lambda:[bot(M),BOTMODE(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu)], fg="black", bg="brown")
    button.grid(column=11, row=0)

    button_reset = Button(fen, text="Restart", command= lambda:[remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN, p, app,jeudameMenu)], fg="black", bg="brown")
    button_reset.grid(column=11, row=1)

    button_menu = Button(fen, text="Menu", command = lambda:[remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN,p,app,jeudameMenu),MEN(),menu(M, n, fen, pionNoir, pionBlanc, caseB, caseN,p,app,jeudameMenu)], fg="brown", bg="ivory")
    button_menu.grid(column=11, row=3)


                
def remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN,p,app,jeudameMenu):
    global alt,autorisation
    MsgBox = messagebox.askquestion(title=None, message="Voulez vous vraiment recommencer la partie ?")
    if MsgBox == 'yes':
        for c in fen.winfo_children():
            c.destroy()

        M = creation_plateau(10)

        if(autorisation == 1):
            Local(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu)
        else:
            BOTMODE(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu)
        alt = 0
        
    else:
        pass
    

def tour():
    global alt
    
    alt += 1
    lab_player.destroy()
   
