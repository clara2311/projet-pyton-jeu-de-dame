#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 12 16:18:59 2021

@author: valentinmerault
"""

import pygame
from tkinter import messagebox
from random import randint


# Gestion du jeux :
    


def afficher(M):
    """
    Affiche une matrice en respectant les alignements par colonnes.
    Peut être utilisé pour observer la matrice à chaque nouvelle action.

    """
    w = [max([len(str(M[i][j])) for i in range(len(M))]) for j in range(len(M[0]))]
    for i in range(len(M)):
        for j in range(len(M[0])):
            print("%*s" % (w[j], str(M[i][j])), end=' ')
        print()


def matriceNulle(n, p):
    "Constructeur de matrice de dimensions données"
    M=[]
    for i in range(n):
        L=[]
        for j in range(p):
            L.append(0)
        M.append(L)
    return M

def creation_plateau(n):
    M = matriceNulle(n, n)

    for i in range(n):

        for j in range(n):

            if (i + j) % 2 == 0:
                M[i][j] = 0
            else:
                M[i][j] = 1

    for i in range(4):
        for i in range(4):

            for j in range(n):
                if M[i][j] == 1:
                    M[i][j] = 3

        for o in range(6, n):

            for p in range(n):

                if M[o][p] == 1:
                    M[o][p] = 2


    return M


def siblanc(i,j,M):
    "Change la valeur de la case dans la matrice, refresh le damier."
    M[i][j] =1

def sinoir(i,j,M):
    "Change la valeur de la case dans la matrice, refresh le damier."
    M[i][j] =1



def sicaseN(i,j,M,alt,p,app):
    "Change la valeur de la case dans la matrice, refresh le damier. Affiche le gagnant"
    n = 10
    if alt%2==0:
        M[i][j] =2
        if (M[i-1][j-1]==3) and (M[i+2][j+2]==1):
            M[i+1][j+1]=1
        elif (M[i+1][j-1]==3) and (M[i+2][j-2]==1):
            M[i+1][j-1]=1

    else:
        M[i][j] =3
        if M[i-1][j-1]==2  and (M[i+2][j-2]==1):
            M[i-1][j-1]=1
        elif M[i-1][j-1]==2 and(M[i-2][j-2]==1):
            M[i-1][j-1]=1
            
    p.set_volume(1)
    p.play()

    wb = win_game_blc(M,n)
    wn = win_game_noir(M,n)

    if wb == True:
        app.set_volume(0.6)
        app.play()
        messagebox.showinfo(title=None, message="Victoire des Blancs")

    else:
        pass

    if wn == True:
        app.set_volume(0.6)
        app.play()
        messagebox.showinfo(title=None, message="Victoire des Noirs")
    else:
        pass


def win_game_blc(damier,n):
    "test si les noirs on encore des pions"
    drapblanc = True
    for i in range(n):
        for j in range(n):
            if damier[i][j] == 3:
                drapblanc = False


    return drapblanc

def win_game_noir(damier,n):
    "test si les blancs on encore des pions"
    drapNoir = True
    for i in range(n):
        for j in range(n):
            if damier[i][j] == 2:
                drapNoir = False


    return drapNoir



def on_closing(fen):
    pygame.mixer.music.stop()
    fen.destroy()
    
    
def bot(M):
    print('JE SUIS DANS ')
    premiereLignePleine = True
    rnd =[-1,1]
    l1 = 3
    l2 = 2
    choix_ligne = randint(l2, l1)
    
    for j in range(1,10):
    
        if M[l1][j] == 1:
            print( M[l1][j])
            premiereLignePleine = False
    
    if premiereLignePleine==True:
        action(M, rnd,l1,l2)
    else:
        pass

def action(M,rnd,l1,l2):
    
    indice = randint(0,8)
        
    if indice%2 !=0 :
        correction = rnd[randint(0,1)]
        indice += rnd[correction]
            
        
    if indice == 0:
        M[l1][indice] = 1
        M[l1+1][indice +  1] = 3
    else:
        M[l1][indice] = 1
        M[l1+1][indice +  rnd[randint(0, 1)]] = 3
    


"""def action2(M,rnd,l1,l2):
    
    indice = randint(1,9)
    
    
    while(M[l2][indice])
    
    if indice%2 ==0 :
        correction = rnd[randint(0,1)]
        indice += rnd[correction]
    
    if M[l2][indice-1] ==
        M[l2][indice] = 1
        M[l2+1][indice +  rnd[randint(0, 1)]] = 3
            
    
    

            
    afficher(M)"""