#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr  4 21:40:19 2021

@author: valentinmerault
"""

from random import *

def afficher(M):
    """
    Affiche une matrice en respectant les alignements par colonnes.
    Peut être utilisé pour observer la matrice à chaque nouvelle action.

    """
    w = [max([len(str(M[i][j])) for i in range(len(M))]) for j in range(len(M[0]))]
    for i in range(len(M)):
        for j in range(len(M[0])):
            print("%*s" % (w[j], str(M[i][j])), end=' ')
        print()


def matriceNulle(n, p):
    "Constructeur de matrice de dimensions données"
    M = []
    for i in range(n):
        L = []
        for j in range(p):
            L.append(10)
        M.append(L)
    return M


def ajout_col(M):
    n = 12
    N = matriceNulle(len(M)+1, len(M[0])+1)

    for i in range(len(M)):
        N[i][len(N[0])-1] = 10

    for i in range(1, n - 1):

        for j in range(1, n - 1):

            if (i + j) % 2 == 0:
                N[i][j] = 0
            else:
                N[i][j] = 1

  

    return N


def creation_plateau(n):
    """ Créer une matrice correspondant au damier """
    M = matriceNulle(n, n)

    for i in range(1, n - 1):

        for j in range(1, n - 1):

            if (i + j) % 2 == 0:
                M[i][j] = 0
            else:
                M[i][j] = 1

    return M


i = 10
j = 5

M = creation_plateau(12)
M = ajout_col(M)
M[i][j] = 8

afficher(M)


dispo1 = False
dispo2 = False
dispo3 = False
dispo4 = False

trouver = False

def detect(M,i,j,trouver):
    m = 0
    k = 0
    maxi = 0
    maxj = 0
    
    
    while(trouver == False):
        
        while (M[i-k][j+m] !=10):
        
             if ( M[i-k][j+m] == 1) or  (M[i-k][j+m] == 6):
                 dispo = True
                 trouver = True
                 maxi = i-k
                 maxj = j+m
             elif M[i-k][j+m] == 3:
                               
                 break
             elif M[i-k][j+m] == 2:
                              
                 break
                         
             
             
    print("Une Dame noire a la possibilité de ce déplacer dans la diagonale top droite limite :", maxi, maxj)


detect(M,i,j,trouver)
