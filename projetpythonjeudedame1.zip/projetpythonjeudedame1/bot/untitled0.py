#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 31 13:52:51 2021

@author: valentinmerault
"""
from random import *

def afficher(M):
    """
    Affiche une matrice en respectant les alignements par colonnes.
    Peut être utilisé pour observer la matrice à chaque nouvelle action.

    """
    w = [max([len(str(M[i][j])) for i in range(len(M))]) for j in range(len(M[0]))]
    for i in range(len(M)):
        for j in range(len(M[0])):
            print("%*s" % (w[j], str(M[i][j])), end=' ')
        print()


def matriceNulle(n, p):
    "Constructeur de matrice de dimensions données"
    M = []
    for i in range(n):
        L = []
        for j in range(p):
            L.append(10)
        M.append(L)
    return M


def ajout_col(M):
    n = 12
    N = matriceNulle(len(M)+1, len(M[0])+1)

    for i in range(len(M)):
        N[i][len(N[0])-1] = 10

    for i in range(1, n - 1):

        for j in range(1, n - 1):

            if (i + j) % 2 == 0:
                N[i][j] = 0
            else:
                N[i][j] = 1

  

    return N


def creation_plateau(n):
    """ Créer une matrice correspondant au damier """
    M = matriceNulle(n, n)

    for i in range(1, n - 1):

        for j in range(1, n - 1):

            if (i + j) % 2 == 0:
                M[i][j] = 0
            else:
                M[i][j] = 1

    return M


i = 10
j = 5

M = creation_plateau(12)
M = ajout_col(M)
M[i][j] = 8

afficher(M)

global dispo1
global dispo2
global dispo3
global dispo4
dispo1 = False
dispo2 = False
dispo3 = False
dispo4 = False

global trouver
trouver = False



while(trouver == False):
        
        m = 0
        k = 0
        maxi1 = 0
        maxj1 = 0
        count = 0
        while (M[i-k][j+m] !=10):
        
             if ( M[i-k][j+m] == 1) or  (M[i-k][j+m] == 6):
                 dispo1 = True
                 trouver = True
                 maxi1 = i-k
                 maxj1 = j+m
                 count += 1 
             elif M[i-k][j+m] == 3:
                               
                 break
             elif M[i-k][j+m] == 2:
                              
                 break
             m += 1
             k += 1
        print()
        print("Une Dame noire a la possibilité de ce déplacer dans la diagonale top droite limite :", maxi1, maxj1)
        afficher(M)
    
        m = 0
        k = 0
        maxi2 = 0
        maxj2 = 0
        count2 = 0
        while (M[i-k][j-m] !=10):
        
             if ( M[i-k][j-m] == 1) or  (M[i-k][j-m] == 6):
                 dispo2 = True
                 trouver = True
                 maxi2 = i-k
                 maxj2 = j-m
                 count2 += 1 
             elif M[i-k][j-m] == 3:
                               
                 break
             elif M[i-k][j-m] == 2:
                              
                 break
             m += 1
             k += 1
             
        print()
        print("Une Dame noire a la possibilité de ce déplacer dans la diagonale top gauche limite :", maxi2, maxj2)
        afficher(M)



if (dispo1== True) & (dispo2 == True):
    choice = randint(1,2)
    print()
    print("On choisi random entre droite et gauche")
    
    if choice == 1:
        print()
        print("Déplacement diagonale droite ")
        print()
        print(maxi1)
        rnd = randint(1,count+(i-10))
        M[i][j] = 1
        M[i-rnd][j+rnd] = 8
        print("on ajoute",rnd)
        print("Dame placé en",i-rnd, j+rnd)
        afficher(M)
        
    elif choice ==2:
        print()
        print("Déplacement diagonale gauche ")
        print(maxi2)
        rnd = randint(1,count2)
       
        print("on ajoute",rnd) 
        M[i][j] = 1
        M[i-rnd][j-rnd] = 8
        print("Dame placé en",i-rnd, j-rnd)
        afficher(M)
        
        
                       
        




"""

   # Dame BAS gauche:  
                if (dispo == False) & (dispo2 == False):
                    maxi = 0
                    maxj = 0
                    
                    k = 0
                    m = 0
                    
                    while (M[i+k][j-m] !=10):
        
                       if  (M[i+k][j-m] == 1) or  (M[i+k][j-m] == 6):
                           dispo3 = True
                           maxi += 1
                           maxj -= 1
                           
                       elif M[i+k][j-m] == 3:
                           
                            break
                       elif M[i+k][j-m] == 2:
                          
                            break
                        
                           
                       else:
                           dispo3 = False
                    
                       k+=1
                       m+=1
                             
                    print(dispo3 ,"jusqua", "indice :",maxi,"et ",maxj)
                    afficher(M)
                    
                
                    if (pion == False) & (dispo3  == True):
                        rnd = randint(1,10+maxj-1)
                        print(rnd)
                        M[i][j] = 1
                        M[i+rnd][j-rnd] = 8
                        afficher(M)
                        print("Dame placé en",(i+rnd),(j-rnd))
                        pion = True
                        find = True
                        cond = False
                        break
                    
            # Dame BAS droite:  
                if (dispo == False) & (dispo2 == False) & (dispo3 == False):
                    maxi = 0
                    maxj = 0
                    
                    k = 0
                    m = 0
                    while (M[i+k][j+m] !=10):
        
                       if  (M[i+k][+-m] == 1) or  (M[i+k][j+m] == 6):
                           dispo4 = True
                           maxi += 1
                           maxj +=1
                       elif M[i+k][j+m] == 3:
                           
                            break
                       elif M[i+k][j+m] == 2:
                          
                            break
                        
                           
                       else:
                           dispo4 = False
                    
                       k+=1
                       m+=1
                             
                    print(dispo ,"jusqua", "indice :",maxi,"et ",maxj)
                    afficher(M)
                    
                
                    if (pion == False) & (dispo4  == True):
                        rnd = randint(1,10-maxj-1)
                        print(rnd)
                        M[i][j] = 1
                        M[i+rnd][j+rnd] = 8
                        afficher(M)
                        print("Dame placé en",(i+rnd),(j+rnd))
                        pion = True
                        find = True
                        cond = False
                        break
                
chemin1 = False
k = -1

while chemin1 == False:
    
    if (M[(i-rnd)+k-1][(j+rnd)+k-1] == 3) & ( M[(i-rnd)+k-2][(j+rnd)+k-2] == 1):
          M[i-rnd][j+rnd] = 1
          M[(i-rnd)+k-1][(j+rnd)+k-1] = 1
          M[(i-rnd)+k-2][(j+rnd)+k-2] = 8
          print("Un pion a été pris")
          chemin = True
          afficher(M)
          break
    else:
         chemin = True
         break

    

"""
