#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 12 16:18:34 2021

@author: claragarnier
"""

from tkinter import Button, Label, Toplevel, PhotoImage

from datas import *

global alt
alt = 0

global autorisation
autorisation = 0

global mode
mode = 0


def create_windows(fen):
    window = Toplevel(fen)
    chevauchementrègle = PhotoImage(file="images/chevauchement1.png")
    deplacementdespions = PhotoImage(file="images/deplacementdespionsregles.png")
    damerègle = PhotoImage(file="images/damesregles.png")
    window.geometry("415x600")
    window.resizable(False, False)  # Dimension de la fenêtre fixe.
    window.configure(bg="#E9D7A6")
    window.title("Jeu de Dame")
    title = Label(window, font='Ubuntu 18', width=55, text="Comment jouer ?", bg="#E9D7A6", fg="brown")
    text1 = Label(window, font='Ubuntu 9',
                  text="I- Pour déplacer un pion il vous suffit juste de faire un clic gauche dessus,\n ensuite un second clic gauche là où vous souhaitez le déposer.",
                  bg="#E9D7A6", fg="black")
    button = Button(window, borderwidth=0, image=deplacementdespions, width=130, height=130)
    text2 = Label(window, font='Ubuntu 9',
                  text="II-Le chevauchement est autorisé, pour pouvoir s'en servir il vous suffit de \n l'activer en faisant un clic gauche sur le bouton que vous trouverez à droite \n du plateau.",
                  bg="#E9D7A6", fg="black")
    button1 = Button(window, borderwidth=0, image=chevauchementrègle, width=130, height=130)
    text3 = Label(window, font='Ubuntu 9',
                  text="III-Pour pouvoir transformer un de vos pions en dame, il suffit que votre pion \n atteigne l'extrémité du damier adverse.",
                  bg="#E9D7A6", fg="black")
    button2 = Button(window, borderwidth=0, image=damerègle, width=130, height=130)
    title.pack(padx=0, pady=10)
    text1.pack(padx=0, pady=0)
    button.pack(padx=0, pady=0)
    text2.pack()
    button1.pack(padx=0, pady=0)
    text3.pack()
    button2.pack(padx=0, pady=0)
    window.mainloop()


def create_windowsbot(fen):
    window = Toplevel(fen)
    chevauchementrègle = PhotoImage(file="images/chevauchement1.png")
    deplacementdespions = PhotoImage(file="images/deplacementdespionsregles.png")
    damerègle = PhotoImage(file="images/damesregles.png")
    window.geometry("415x600")
    window.resizable(False, False)  # Dimension de la fenêtre fixe.
    window.configure(bg="#E9D7A6")
    window.title("Jeu de Dame")
    title = Label(window, font='Ubuntu 18', width=55, text="Comment jouer ?", bg="#E9D7A6", fg="brown")
    text1 = Label(window, font='Ubuntu 9',
                  text="I- Pour déplacer un pion il vous suffit juste de faire un clic gauche dessus,\n ensuite un second clic gauche là où vous souhaitez le déposer. Ensuite,\n appuyez sur « fin de tour » et le pion noir sera joué.",
                  bg="#E9D7A6", fg="black")
    button = Button(window, borderwidth=0, image=deplacementdespions, width=130, height=130)
    text2 = Label(window, font='Ubuntu 9',
                  text="II-Le chevauchement est autorisé, pour pouvoir s'en servir il vous suffit de \n l'activer en faisant un clic gauche sur le bouton que vous trouverez à droite \n du plateau.",
                  bg="#E9D7A6", fg="black")
    button1 = Button(window, borderwidth=0, image=chevauchementrègle, width=130, height=130)
    text3 = Label(window, font='Ubuntu 9',
                  text="III-Pour pouvoir transformer un de vos pions en dame, il suffit que votre pion \n atteigne l'extrémité du damier adverse.",
                  bg="#E9D7A6", fg="black")
    button2 = Button(window, borderwidth=0, image=damerègle, width=130, height=130)
    title.pack(padx=0, pady=10)
    text1.pack(padx=0, pady=0)
    button.pack(padx=0, pady=0)
    text2.pack()
    button1.pack(padx=0, pady=0)
    text3.pack()
    button2.pack(padx=0, pady=0)
    window.mainloop()
    

def interface():
    global autorisation
    autorisation = 1


def MEN():
    global autorisation
    autorisation = 0


def mode_bot():
    global autorisation
    autorisation = 2


def reset(fen):
    for c in fen.winfo_children():
        c.destroy()


def caseBlanche(i, j, tk, caseB):
    button = Button(tk, image=caseB, borderwidth=0, width = 55, height = 55)
    button.grid(column=j, row=i)


def caseNoire(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2):
    global alt
    button = Button(fen, borderwidth=0, image=caseN,
                    command=lambda: [sicaseN(i, j, M, alt, p, app),
                                     Local(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame,
                                           pionDame2)]
                    , width = 55, height = 55)
    button.grid(column=j, row=i)


def caseBOT(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2):
    global alt
    button = Button(fen,borderwidth=0, image=caseN,
                    command=lambda: [sicaseN(i, j, M, alt, p, app),
                                     BOTMODE(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu,
                                             pionDame, pionDame2)]
                    , width = 55, height = 55)
    button.grid(column=j, row=i)


def pionN(i, j, fen, M, pionNoir):
    button = Button(fen,borderwidth=0, image=pionNoir,
                    command=lambda: [sinoir(i, j, M)]
                    , width = 55, height = 55)
    button.grid(column=j, row=i)


def pionB(i, j, fen, pionBlanc, M):
    button = Button(fen,borderwidth=0, image=pionBlanc,
                    command=lambda: [siblanc(i, j, M)]
                   ,width = 55, height = 55)
    button.grid(column=j, row=i)


def dameB(i, j, fen, M, pionDame):
    button = Button(fen, borderwidth=0, image=pionDame,
                    command=lambda: [siblancD(i, j, M)]
                    , width = 55, height = 55)
    button.grid(column=j, row=i)


def dameN(i, j, fen, M, pionDame2):
    button = Button(fen,borderwidth=0, image=pionDame2,
                    command=lambda: [sinoirD(i, j, M)]
                    , width = 55, height = 55)
    button.grid(column=j, row=i)


def menu(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2):
    M = creation_plateau(12)

    reset(fen)

    mainTitre = Label(fen, text="Bienvenue", fg="brown", bg="#E9D7A6", font="Ubuntu 30")
    mainTitre.pack(padx=0, pady=30)

    button = Button(fen, borderwidth=0, image=jeudameMenu, width=400, height=408)
    button.pack(padx=100, pady=10)

    button_start = Button(fen, text="Partie locale", fg="brown", bg="ivory", command=lambda: [interface(),
                                                                                              Local(M, n, fen, pionNoir,
                                                                                                    pionBlanc, caseB,
                                                                                                    caseN, p,
                                                                                                    app, jeudameMenu,
                                                                                                    pionDame,
                                                                                                    pionDame2)])
    button_start.pack(padx=5, pady=5)

    button_BOT = Button(fen, text="Partie vs l'ordinateur", fg="brown", bg="ivory",
                        command=lambda: [mode_bot(),
                                         BOTMODE(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu,
                                                 pionDame, pionDame2)]
                        )
    button_BOT.pack(padx=5, pady=5)

    button_ONLINE = Button(fen, text="Partie en ligne (en développement)", fg="brown", bg="ivory",
                           command=lambda: [interface(),
                                            Local(M, n, fen,
                                                  pionNoir,
                                                  pionBlanc, caseB,
                                                  caseN,
                                                  p, app,
                                                  jeudameMenu,
                                                  pionDame,
                                                  pionDame2)])
    button_ONLINE.pack(padx=5, pady=5)


def Local(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2):
    global alt, autorisation, lab_player
    afficher(M)
    reset(fen)

    for i in range(1, n - 1):

        for j in range(1, n - 1):

            if M[i][j] == 0:
                caseBlanche(i, j, fen, caseB)
            elif (M[i][j] == 1) or (M[i][j] == 5) or (M[i][j] == 6):
                caseNoire(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2)
            elif M[i][j] == 3:
                pionN(i, j, fen, M, pionNoir)
            elif M[i][j] == 7:
                dameB(i, j, fen, M, pionDame)
            elif M[i][j] == 8:
                dameN(i, j, fen, M, pionDame2)
            else:
                pionB(i, j, fen, pionBlanc, M)

    button = Button(fen, text="Fin de Tour", command=lambda: [tour(),
                                                              Local(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p,
                                                                    app, jeudameMenu, pionDame, pionDame2)], fg="brown",
                    bg="ivory")
    button.grid(column=11, row=2)

    button_Regle = Button(fen, text="RÈGLES", fg="brown", bg="ivory", command=lambda: [create_windows(fen)])
    button_Regle.grid(column=11, row=6)

    button_reset = Button(fen, text="Restart", command=lambda: [
        remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, lab_player, pionDame, pionDame2)],
                          fg="brown", bg="ivory")
    button_reset.grid(column=11, row=4)

    button_menu = Button(fen, text="Menu", command=lambda: [
        remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, lab_player, pionDame, pionDame2),
        MEN(), menu(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2)],
                         fg="brown", bg="ivory")
    button_menu.grid(column=11, row=5)

    button_chev = Button(fen, text="CHEVAUCHER", command=lambda: [chevauchement()], fg="red", bg="ivory")
    button_chev.grid(column=11, row=3)

    lab_player = Label(fen, text="À toi :\n Blanc", fg="brown", bg="#E9D7A6", font="Ubuntu 15")
    lab_player.grid(column=11, row=1)

    if alt % 2 == 0:
        lab_player['text'] = "À toi :\n Blanc "
    else:
        lab_player['text'] = "À toi :\n Noir "



def BOTMODE(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2):
    global alt, autorisation, mode

    alt = 0
    reset(fen)

    for i in range(1, n - 1):

        for j in range(1, n - 1):

            if M[i][j] == 0:
                caseBlanche(i, j, fen, caseB)
            elif (M[i][j] == 1) or (M[i][j] == 5) or (M[i][j] == 6):
                caseBOT(i, j, fen, pionBlanc, M, pionNoir, n, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2)
            elif M[i][j] == 3:
                pionN(i, j, fen, M, pionNoir)
            elif M[i][j] == 7:
                dameB(i, j, fen, M, pionDame)
            elif M[i][j] == 8:
                dameN(i, j, fen, M, pionDame2)
            else:
                pionB(i, j, fen, pionBlanc, M)

    button = Button(fen, text="Fin de Tour", command=lambda: [tour(), prisePionBOT(M),
                                                              BOTMODE(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p,
                                                                      app, jeudameMenu, pionDame, pionDame2)],
                    fg="brown", bg="ivory")
    button.grid(column=11, row=2)

    button_Regle = Button(fen, text="RÈGLES", fg="brown", bg="ivory", command=lambda: [create_windowsbot(fen)])
    button_Regle.grid(column=11, row=6)

    button_reset = Button(fen, text="Restart", command=lambda: [
        remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, lab_player, pionDame, pionDame2)],
                          fg="brown", bg="ivory")
    button_reset.grid(column=11, row=4)

    button_chev = Button(fen, text="CHEVAUCHER", command=lambda: [chevauchement()], fg="red", bg="ivory")
    button_chev.grid(column=11, row=3)

    button_menu = Button(fen, text="Menu", command=lambda: [
        remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, lab_player, pionDame, pionDame2),
        MEN(), menu(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2)],
                         fg="brown", bg="ivory")
    button_menu.grid(column=11, row=5)

    lab_player = Label(fen, text="A toi", fg="brown", bg="#E9D7A6", font="Ubuntu 15")

def remettre_a0(n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, lab_player, pionDame, pionDame2):
    global alt, autorisation
    MsgBox = messagebox.askquestion(title=None, message="Voulez vous vraiment recommencer/quitter la partie ?")
    if MsgBox == 'yes':
        for c in fen.winfo_children():
            c.destroy()

        M = creation_plateau(n)
        alt = 0

        if (autorisation == 1):
            Local(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2)
        else:
            BOTMODE(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2)


    else:
        pass


def tour():
    global alt

    alt += 1
