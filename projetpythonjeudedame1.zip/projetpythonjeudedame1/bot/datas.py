#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 12 16:18:59 2021

@author: claragarnier
"""
from turtle import goto

import pygame
from tkinter import messagebox
from random import randint

# Gestion du jeux :

global chevaucher
chevaucher = False


def afficher(M):
    """
    Affiche une matrice en respectant les alignements par colonnes.
    Peut être utilisé pour observer la matrice à chaque nouvelle action.

    """
    w = [max([len(str(M[i][j])) for i in range(len(M))]) for j in range(len(M[0]))]
    for i in range(len(M)):
        for j in range(len(M[0])):
            print("%*s" % (w[j], str(M[i][j])), end=' ')
        print()


def matriceNulle(n, p):
    "Constructeur de matrice de dimensions données"
    M = []
    for i in range(n):
        L = []
        for j in range(p):
            L.append(10)
        M.append(L)
    return M


def creation_plateau(n):
    M = matriceNulle(n, n)

    for i in range(1, n - 1):

        for j in range(1, n - 1):

            if (i + j) % 2 == 0:
                M[i][j] = 0
            else:
                M[i][j] = 1

    for i in range(1, 5):

        for j in range(1, n - 1):
            if M[i][j] == 1:
                M[i][j] = 3

        for o in range(7, n - 1):

            for p in range(1, n - 1):

                if M[o][p] == 1:
                    M[o][p] = 2

    return M


def siblanc(i, j, M):
    "Change la valeur de la case dans la matrice, refresh le damier."
    M[i][j] = 5


def sinoir(i, j, M):
    "Change la valeur de la case dans la matrice, refresh le damier."
    M[i][j] = 6

def siblancD(i, j, M):
    "Change la valeur de la case dans la matrice, refresh le damier."
    M[i][j] = 7


def sinoirD(i, j, M):
    "Change la valeur de la case dans la matrice, refresh le damier."
    M[i][j] = 8


def chevauchement():
    global chevaucher
    chevaucher = True


def detecDame(M):
    dame = False
    for j in range(1, 10):
        if M[1][j] == 2:
            
            dame = True
            M[1][j] = 7
    for j in range(1, 10):
        if M[10][j] == 3:
          
            dame = True
            M[10][j] = 8

    return dame


def sicaseN(i, j, M, alt, p, app):
    "Change la valeur de la case dans la matrice, refresh le damier. Détermine le gagnant"
    global chevaucher
    n = 12

    if chevaucher == False:

        if alt % 2 == 0:

            M[i][j] = 2

            detecDame(M)

            if (M[i - 1][j - 1] == 7):

                M[i][j] = 7
                M[i - 1][j - 1] = 1

            elif (M[i - 1][j + 1] == 7):

                M[i][j] = 7
                M[i - 1][j + 1] = 1

            elif (M[i + 1][j + 1] == 7):

                M[i][j] = 7
                M[i + 1][j + 1] = 1

            elif (M[i + 1][j - 1] == 7):

                M[i][j] = 7
                M[i + 1][j - 1] = 1
            
    


            elif ((M[i + 1][j - 1] == 3) and (M[i + 2][j - 2] == 5)):
                M[i + 1][j - 1] = 1
                M[i + 2][j - 2] = 1

            elif ((M[i + 1][j + 1] == 3) and (M[i + 2][j + 2] == 5)):
                M[i + 1][j + 1] = 1
                M[i + 2][j + 2] = 1

            if (M[i + 1][j + 1] == 5):
                M[i + 1][j + 1] = 1
            elif ((M[i + 1][j - 1] == 5)):
                M[i + 1][j - 1] = 1



        elif alt % 2 != 0:

            M[i][j] = 3
            detecDame(M)

            if (M[i - 1][j - 1] == 8):

                M[i][j] = 8
                M[i - 1][j - 1] = 1

            elif (M[i - 1][j + 1] == 8):
               

                M[i][j] = 8
                M[i - 1][j + 1] = 1

            elif (M[i + 1][j + 1] == 8):

                M[i][j] = 8
                M[i + 1][j + 1] = 1

            elif (M[i + 1][j - 1] == 8):

                M[i][j] = 8
                M[i + 1][j - 1] = 1
                
        

            elif ((M[i - 1][j + 1] == 2) and (M[i - 2][j + 2] == 6)):
                M[i - 1][j + 1] = 1
                M[i - 2][j + 2] = 6
            elif ((M[i - 1][j - 1] == 2) and (M[i - 2][j - 2] == 6)):
                M[i - 1][j - 1] = 1
                M[i - 2][j - 2] = 6

            if (M[i - 1][j + 1] == 6):
                M[i - 1][j + 1] = 1
            elif ((M[i - 1][j - 1] == 6)):
                M[i - 1][j - 1] = 1

    if chevaucher == True:
       
        if alt % 2 == 0:

            M[i][j] = 2

            detecDame(M)

            if ((M[i + 1][j - 1] == 3) and (M[i + 2][j - 2] == 5)):
                M[i + 1][j - 1] = 1
                M[i + 2][j - 2] = 1

            elif ((M[i + 1][j + 1] == 3) and (M[i + 2][j + 2] == 5)):
                M[i + 1][j + 1] = 1
                M[i + 2][j + 2] = 1

            if ((M[i - 1][j + 1] == 3) and (M[i - 2][j + 2] == 5)):
                M[i - 1][j + 1] = 1
                M[i - 2][j + 2] = 6
            elif ((M[i - 1][j - 1] == 3) and (M[i - 2][j - 2] == 5)):
                M[i - 1][j - 1] = 1
                M[i - 2][j - 2] = 6

            if (M[i + 1][j + 1] == 5):
                M[i + 1][j + 1] = 1
            elif ((M[i + 1][j - 1] == 5)):
                M[i + 1][j - 1] = 1


        elif alt % 2 != 0:
            M[i][j] = 3
            detecDame(M)

            if ((M[i - 1][j + 1] == 2) and (M[i - 2][j + 2] == 6)):
                M[i - 1][j + 1] = 1
                M[i - 2][j + 2] = 6
            elif ((M[i - 1][j - 1] == 2) and (M[i - 2][j - 2] == 6)):
                M[i - 1][j - 1] = 1
                M[i - 2][j - 2] = 6
            if ((M[i + 1][j - 1] == 2) and (M[i + 2][j - 2] == 6)):
                M[i + 1][j - 1] = 1
                M[i + 2][j - 2] = 1

            elif ((M[i + 1][j + 1] == 2) and (M[i + 2][j + 2] == 6)):
                M[i + 1][j + 1] = 1
                M[i + 2][j + 2] = 1

            if (M[i - 1][j + 1] == 6):
                M[i - 1][j + 1] = 1
            elif ((M[i - 1][j - 1] == 6)):
                M[i - 1][j - 1] = 1

    p.set_volume(1)
    p.play()

    wb = win_game_blc(M, n)
    wn = win_game_noir(M, n)

    if wb == True:
        app.set_volume(0.6)
        app.play()
        messagebox.showinfo(title=None, message="Victoire des Blancs")

    else:
        pass

    if wn == True:
        app.set_volume(0.6)
        app.play()
        messagebox.showinfo(title=None, message="Victoire des Noirs")
    else:
        pass


def win_game_blc(damier, n):
    "test si les noirs on encore des pions"
    drapblanc = True
    for i in range(n):
        for j in range(n):
            if damier[i][j] == 3:
                drapblanc = False

    return drapblanc


def win_game_noir(damier, n):
    "test si les blancs on encore des pions"
    drapNoir = True
    for i in range(n):
        for j in range(n):
            if damier[i][j] == 2:
                drapNoir = False

    return drapNoir


def on_closing(fen):
    pygame.mixer.music.stop()
    fen.destroy()


def prisePionBOT(M):
    liste = [-1, 1]
    find = False
    condition = False
    cond = True
    while find == False:

        for i in range(1, len(M) - 2):
            if condition: break
            for j in range(1, len(M) - 2):

                if (M[i][j] == 3) & (M[i + 1][j + 1] == 2) & (M[i + 2][j + 2] == 1 or M[i + 2][j + 2] == 5):

                    M[i][j] = 1
                    M[i + 1][j + 1] = 1
                    M[i + 2][j + 2] = 3
                    find = True
                    condition = True
                    break


                elif (M[i][j] == 3) & (M[i + 1][j - 1] == 2) & (M[i + 2][j - 2] == 1 or M[i + 2][j + 2] == 5):

                    M[i][j] = 1
                    M[i + 1][j - 1] = 1
                    M[i + 2][j - 2] = 3
                    find = True
                    condition = True
                    break

        while (cond == True) & (find == False):
            i = randint(1, 10)
            j = randint(1, 10)

            if (M[i][j] == 3) & (M[i + 1][j + 1] == 1) & (M[i + 1][j - 1] == 1):
                M[i + 1][j + liste[randint(0, 1)]] = 3
                M[i][j] = 1
                find = True
                cond = False
            elif (M[i][j] == 3) & (M[i + 1][j + 1] == 1):
                M[i + 1][j + 1] = 3
                M[i][j] = 1
                find = True
                cond = False
            elif (M[i][j] == 3) & (M[i + 1][j - 1] == 1):
                M[i + 1][j - 1] = 3
                M[i][j] = 1
                find = True
                cond = False
