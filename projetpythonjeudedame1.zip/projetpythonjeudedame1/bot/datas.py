#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 12 16:18:59 2021

@author: valentin merault
"""

import pygame
from tkinter import messagebox
from random import randint

# Variable gèrant le chevauchement :

global chevaucher
chevaucher = False

global damePlay
damePlay = False

# Variable gérant les pion soufflé :
global savei
global savej

savei = 0
savej = 0

global saveN

# Pions/Dames Blancs
global Bsoufl_bas_gauche, Bsoufl_bas_droite, Bsoufl_haut_gauche, Bsoufl_haut_droite
Bsoufl_bas_gauche, Bsoufl_bas_droite, Bsoufl_haut_gauche, Bsoufl_haut_droite = False, False, False, False

global DBsoufl_bas_gauche, DBsoufl_bas_droite, DBsoufl_haut_gauche, DBsoufl_haut_droite
DBsoufl_bas_gauche, DBsoufl_bas_droite, DBsoufl_haut_gauche, DBsoufl_haut_droite = False, False, False, False

# Pions/Dames Noirs

global Nsoufl_bas_gauche, Nsoufl_bas_droite, Nsoufl_haut_gauche, Nsoufl_haut_droite
Nsoufl_bas_gauche, Nsoufl_bas_droite, Nsoufl_haut_gauche, Nsoufl_haut_droite = False, False, False, False

global DNsoufl_bas_gauche, DNsoufl_bas_droite, DNsoufl_haut_gauche, DNsoufl_haut_droite
DNsoufl_bas_gauche, DNsoufl_bas_droite, DNsoufl_haut_gauche, DNsoufl_haut_droite = False, False, False, False

# Désactiver / activer le pion soufflé : 
global activ_desac
activ_desac = 1

global act
act = True


def activer_desactiversouf():
    global activ_desac, act

    " Désactiver / activer le pion soufflé : "

    if (activ_desac % 2) == 0:
        act = True

    else:
        act = False

    activ_desac += 1


def reset_acti():
    global act, activ_desac
    " Remise a zero lors d'un reset ou retour menu "
    act = True
    activ_desac = 0


def reset_souf():
    global savei, savej, Bsoufl_bas_gauche, Bsoufl_bas_droite, Bsoufl_haut_droite, Bsoufl_haut_gauche, act, activ_desac, Nsoufl_bas_gauche, Nsoufl_bas_droite, Nsoufl_haut_gauche, Nsoufl_haut_droite, act, DBsoufl_bas_gauche, DBsoufl_bas_droite, DBsoufl_haut_droite, DBsoufl_haut_gauche, DNsoufl_bas_gauche, DNsoufl_bas_droite, DNsoufl_haut_gauche, DNsoufl_haut_droite
    " Remet a zero toutes les variables de conditions "
    savei = 0
    savej = 0

    Bsoufl_bas_gauche, Bsoufl_bas_droite, Bsoufl_haut_gauche, Bsoufl_haut_droite = False, False, False, False
    Nsoufl_bas_gauche, Nsoufl_bas_droite, Nsoufl_haut_gauche, Nsoufl_haut_droite = False, False, False, False
    DNsoufl_bas_gauche, DNsoufl_bas_droite, DNsoufl_haut_gauche, DNsoufl_haut_droite = False, False, False, False
    DBsoufl_bas_gauche, DBsoufl_bas_droite, DBsoufl_haut_gauche, DBsoufl_haut_droite = False, False, False, False


def saveNB(M, alt):
    global saveN, savei, savej, Bsoufl_bas_gauche, Bsoufl_bas_droite, Bsoufl_haut_droite, Bsoufl_haut_gauche, Nsoufl_bas_gauche, Nsoufl_bas_droite, Nsoufl_haut_gauche, Nsoufl_haut_droite, act, DNsoufl_bas_gauche, DNsoufl_bas_droite, DNsoufl_haut_gauche, DNsoufl_haut_droite, DBsoufl_bas_gauche, DBsoufl_bas_droite, DBsoufl_haut_droite, DBsoufl_haut_gauche
    """ Sauvegarde la matrice avant mouvement, détecte si un pion peut être soufflable."""
    if (act == True) & (chevaucher == False):
        saveN = M
        if (alt % 2) == 0:
            saveN = M
            for i in range(1, 11):

                for j in range(1, 11):

                    if (saveN[i][j] == 2) & ((saveN[i + 1][j - 1] == 3) or (saveN[i + 1][j - 1] == 8)) & (
                            saveN[i + 2][j - 2] == 1):
                        savei = i
                        savej = j

                        Bsoufl_bas_gauche = True
                        break

                    elif (saveN[i][j] == 2) & ((saveN[i + 1][j + 1] == 3) or (saveN[i + 1][j + 1] == 8)) & (
                            saveN[i + 2][j + 2] == 1):
                        savei = i
                        savej = j

                        Bsoufl_bas_droite = True
                        break

                    elif (saveN[i][j] == 2) & ((saveN[i - 1][j - 1] == 3) or (saveN[i - 1][j - 1] == 8)) & (
                            saveN[i - 2][j - 2] == 1):
                        savei = i
                        savej = j

                        Bsoufl_haut_gauche = True
                        break

                    elif (saveN[i][j] == 2) & ((saveN[i - 1][j + 1] == 3) or (saveN[i - 1][j + 1] == 8)) & (
                            saveN[i - 2][j + 2] == 1):
                        savei = i
                        savej = j

                        Bsoufl_haut_droite = True
                        break

                    # Dames Blanches :
                    if (saveN[i][j] == 7) & ((saveN[i + 1][j - 1] == 3) or (saveN[i + 1][j - 1] == 8)) & (
                            saveN[i + 2][j - 2] == 1):
                        savei = i
                        savej = j

                        DBsoufl_bas_gauche = True
                        break

                    elif (saveN[i][j] == 7) & ((saveN[i + 1][j + 1] == 3) or (saveN[i + 1][j + 1] == 8)) & (
                            saveN[i + 2][j + 2] == 1):
                        savei = i
                        savej = j

                        DBsoufl_bas_droite = True
                        break

                    elif (saveN[i][j] == 7) & ((saveN[i - 1][j - 1] == 3) or (saveN[i - 1][j - 1] == 8)) & (
                            saveN[i - 2][j - 2] == 1):
                        savei = i
                        savej = j

                        DBsoufl_haut_gauche = True
                        break

                    elif (saveN[i][j] == 7) & ((saveN[i - 1][j + 1] == 3) or (saveN[i - 1][j + 1] == 8)) & (
                            saveN[i - 2][j + 2] == 1):
                        savei = i
                        savej = j

                        DBsoufl_haut_droite = True
                        break

            return saveN

        elif (alt % 2) != 0:

            for i in range(1, 11):

                for j in range(1, 11):

                    if (saveN[i][j] == 3) & ((saveN[i - 1][j + 1] == 2) or (saveN[i - 1][j + 1] == 7)) & (
                            saveN[i - 2][j + 2] == 1):
                        savei = i
                        savej = j

                        Nsoufl_haut_droite = True
                        break

                    elif (saveN[i][j] == 3) & ((saveN[i - 1][j - 1] == 2) or (saveN[i - 1][j + 1] == 7)) & (
                            saveN[i - 2][j - 2] == 1):
                        savei = i
                        savej = j

                        Nsoufl_haut_gauche = True
                        break

                    elif (saveN[i][j] == 3) & ((saveN[i + 1][j + 1] == 2) or (saveN[i + 1][j + 1] == 7)) & (
                            saveN[i + 2][j + 2] == 1):
                        savei = i
                        savej = j

                        Nsoufl_bas_droite = True
                        break

                    elif (saveN[i][j] == 3) & ((saveN[i + 1][j - 1] == 2) or (saveN[i + 1][j - 1] == 7)) & (
                            saveN[i + 2][j - 2] == 1):
                        savei = i
                        savej = j

                        Nsoufl_bas_gauche = True
                        break

                    # Dames Noires :
                    if (saveN[i][j] == 8) & ((saveN[i + 1][j - 1] == 2) or (saveN[i + 1][j - 1] == 7)) & (
                            saveN[i + 2][j - 2] == 1):
                        savei = i
                        savej = j

                        DNsoufl_bas_gauche = True
                        break

                    elif (saveN[i][j] == 8) & ((saveN[i + 1][j + 1] == 2) or (saveN[i + 1][j + 1] == 7)) & (
                            saveN[i + 2][j + 2] == 1):
                        savei = i
                        savej = j

                        DNsoufl_bas_droite = True
                        break

                    elif (saveN[i][j] == 8) & ((saveN[i - 1][j - 1] == 2) or (saveN[i - 1][j - 1] == 7)) & (
                            saveN[i - 2][j - 2] == 1):
                        savei = i
                        savej = j

                        DNsoufl_haut_gauche = True
                        break

                    elif (saveN[i][j] == 8) & ((saveN[i - 1][j + 1] == 2) or (saveN[i - 1][j + 1] == 7)) & (
                            saveN[i - 2][j + 2] == 1):
                        savei = i
                        savej = j

                        DNsoufl_haut_droite = True
                        break

            return saveN


def SiPasPris_souf(M, N, alt):
    global savei, savej, Bsoufl_bas_gauche, Bsoufl_bas_droite, Bsoufl_haut_droite, Bsoufl_haut_gauche, act, DBsoufl_bas_gauche, DBsoufl_bas_droite, DBsoufl_haut_droite, DBsoufl_haut_gauche

    """ Gère le soufflement des pions et dames Blancs"""
    if (act == True) & (chevaucher == False):
        if (alt % 2) == 0:
            if Bsoufl_haut_droite == True:

                if (((N[savei - 1][savej + 1] == 3) or (N[savei - 1][savej + 1] == 8)) & (
                        (M[savei - 1][savej + 1] == 3) or (M[savei - 1][savej + 1] == 3)) & (M[savei][savej] != 2)):

                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")

                    M[savei - 1][savej - 1] = 1
                    Bsoufl_haut_droite = False

                elif (((N[savei - 1][savej + 1] == 3) or (N[savei - 1][savej + 1] == 8)) & (
                        (M[savei - 1][savej + 1] == 3) or (M[savei - 1][savej + 1] == 3)) & (M[savei][savej] == 2)):
                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                    M[savei][savej] = 1
                    Bsoufl_haut_droite = False
                else:
                    pass

            elif Bsoufl_haut_gauche == True:

                if (((N[savei - 1][savej - 1] == 3) or (N[savei - 1][savej - 1] == 8)) & (
                        (M[savei - 1][savej - 1] == 3) or (M[savei - 1][savej - 1] == 8)) & (M[savei][savej] != 2)):

                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")

                    M[savei - 1][savej + 1] = 1
                    Bsoufl_haut_gauche = False

                elif (((N[savei - 1][savej - 1] == 3) or (N[savei - 1][savej - 1] == 8)) & (
                        (M[savei - 1][savej - 1] == 3) or (M[savei - 1][savej - 1] == 8)) & (M[savei][savej] == 2)):
                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                    M[savei][savej] = 1
                    Bsoufl_haut_gauche = False
                else:
                    pass

            elif Bsoufl_bas_droite == True:

                if (((N[savei + 1][savej + 1] == 3) or (N[savei + 1][savej + 1] == 8)) & (
                        (M[savei + 1][savej + 1] == 3) or (M[savei + 1][savej + 1] == 8)) & (M[savei][savej] == 2)):
                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                    M[savei][savej] = 1
                    Bsoufl_bas_droite = False
                elif (((N[savei + 1][savej + 1] == 3) or (N[savei + 1][savej + 1] == 8)) & (
                        (M[savei + 1][savej + 1] == 3) or (M[savei + 1][savej + 1] == 3)) & (M[savei][savej] != 2)):
                    if (M[savei - 1][savej - 1] == 2):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei - 1][savej - 1] = 1
                        Bsoufl_bas_droite = False

                    elif (M[savei - 1][savej + 1] == 2):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei - 1][savej + 1] = 1
                        Bsoufl_bas_droite = False

                else:
                    pass

            elif Bsoufl_bas_gauche == True:

                if (((N[savei + 1][savej - 1] == 3) or (N[savei + 1][savej - 1] == 8)) & (
                        (M[savei + 1][savej - 1] == 3) or (M[savei + 1][savej - 1] == 8)) & (M[savei][savej] == 2)):
                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                    M[savei][savej] = 1
                    Bsoufl_bas_gauche = False

                elif (((N[savei + 1][savej - 1] == 3) or (N[savei + 1][savej - 1] == 8)) & (
                        (M[savei + 1][savej - 1] == 3) or (M[savei + 1][savej - 1] == 8)) & (M[savei][savej] != 2)):
                    if (M[savei - 1][savej - 1] == 2):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei - 1][savej - 1] = 1
                        Bsoufl_bas_gauche = False

                    elif (M[savei - 1][savej + 1] == 2):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei - 1][savej + 1] = 1
                        Bsoufl_bas_gauche = False
                else:
                    pass
            else:
                Bsoufl_bas_gauche = False
                Bsoufl_bas_droite = False
                Bsoufl_haut_droite = False
                Bsoufl_haut_gauche = False

            # Dame Blanche :

            if DBsoufl_haut_droite == True:

                if (((N[savei - 1][savej + 1] == 3) or (N[savei - 1][savej + 1] == 8)) & (
                        (M[savei - 1][savej + 1] == 3) or (M[savei - 1][savej + 1] == 8)) & (M[savei][savej] != 7)):

                    # Possibilité 1/3 :

                    if (M[savei - 1][savej - 1] == 7):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei - 1][savej - 1] = 1
                        DBsoufl_haut_droite = False

                    # Possibilité 2/3 :

                    elif (M[savei + 1][savej + 1] == 7):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei + 1][savej + 1] = 1
                        DBsoufl_haut_droite = False

                    # Possibilité 3/3 :

                    elif (M[savei + 1][savej - 1] == 7):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei + 1][savej - 1] = 1
                        DBsoufl_haut_droite = False

                elif (((N[savei - 1][savej + 1] == 3) or (N[savei - 1][savej + 1] == 8)) & (
                        (M[savei - 1][savej + 1] == 3) or (M[savei - 1][savej + 1] == 8)) & (M[savei][savej] == 7)):

                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                    M[savei][savej] == 1
                    DBsoufl_haut_droite = False

                else:
                    pass

            elif DBsoufl_haut_gauche == True:

                if (((N[savei - 1][savej - 1] == 3) or (N[savei - 1][savej - 1] == 8)) & (
                        (M[savei - 1][savej - 1] == 3) or (M[savei - 1][savej - 1] == 8)) & (M[savei][savej] != 7)):

                    # Possibilité 1/3 :

                    if (M[savei - 1][savej + 1] == 7):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei - 1][savej + 1] = 1
                        DBsoufl_haut_gauche = False

                    # Possibilité 2/3 :

                    elif (M[savei + 1][savej + 1] == 7):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei + 1][savej + 1] = 1
                        DBsoufl_haut_gauche = False

                    # Possibilité 3/3 :

                    elif (M[savei + 1][savej - 1] == 7):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei + 1][savej - 1] = 1
                        DBsoufl_haut_gauche = False

                elif (((N[savei - 1][savej - 1] == 3) or (N[savei - 1][savej - 1] == 8)) & (
                        (M[savei - 1][savej - 1] == 3) or (M[savei - 1][savej - 1] == 8)) & (M[savei][savej] == 7)):

                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                    M[savei][savej] == 1
                    DBsoufl_haut_gauche = False
                else:
                    pass

            elif DBsoufl_bas_droite == True:

                if (((N[savei + 1][savej + 1] == 3) or (N[savei + 1][savej + 1] == 8)) & (
                        (M[savei + 1][savej + 1] == 3) or (M[savei + 1][savej + 1] == 8)) & (M[savei][savej] == 7)):
                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                    M[savei][savej] = 1
                    DBsoufl_bas_droite = False

                elif (((N[savei + 1][savej + 1] == 3 or N[savei + 1][savej + 1] == 8)) & (
                        (M[savei + 1][savej + 1] == 3) or (M[savei + 1][savej + 1] == 8)) & (M[savei][savej] != 7)):

                    # Possibilité 1/3 :

                    if (M[savei - 1][savej - 1] == 7):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei - 1][savej - 1] = 1
                        DBsoufl_bas_droite = False

                    # Possibilité 2/3 :

                    elif (M[savei - 1][savej + 1] == 7):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei - 1][savej + 1] = 1
                        DBsoufl_bas_droite = False

                    # Possibilité 3/3 :

                    elif (M[savei + 1][savej - 1] == 7):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei + 1][savej - 1] = 1
                        DBsoufl_bas_droite = False

                else:
                    pass

            elif DBsoufl_bas_gauche == True:

                if (((N[savei + 1][savej - 1] == 3) or (N[savei + 1][savej - 1] == 8)) & (
                        (M[savei + 1][savej - 1] == 3) or (M[savei + 1][savej - 1] == 8)) & (M[savei][savej] == 7)):
                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                    M[savei][savej] = 1
                    DBsoufl_bas_gauche = False
                elif (((N[savei + 1][savej - 1] == 3) or (N[savei + 1][savej - 1] == 3)) & (
                        (M[savei + 1][savej - 1] == 3) or (M[savei + 1][savej - 1] == 8)) & (M[savei][savej] != 7)):

                    # Possibilité 1/3 :
                    if (M[savei - 1][savej - 1] == 7):

                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei - 1][savej - 1] = 1
                        DBsoufl_bas_gauche = False

                    # Possibilité 2/3 :
                    elif (M[savei - 1][savej + 1] == 7):

                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei - 1][savej + 1] = 1
                        DBsoufl_bas_gauche = False

                    # Possibilité 3/3 :
                    elif (M[savei + 1][savej + 1] == 7):

                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei + 1][savej + 1] = 1
                        DBsoufl_bas_gauche = False
                else:
                    pass
            else:
                DBsoufl_bas_gauche = False
                DBsoufl_bas_droite = False
                DBsoufl_haut_droite = False
                DBsoufl_haut_gauche = False


def SiPasPris_soufN(M, N, alt):
    global savei, savej, Nsoufl_bas_gauche, Nsoufl_bas_droite, Nsoufl_haut_gauche, Nsoufl_haut_droite, act, DNsoufl_bas_gauche, DNsoufl_bas_droite, DNsoufl_haut_gauche, DNsoufl_haut_droite

    """ Gère le soufflement des pions et dames Noirs"""
    if (act == True) & (chevaucher == False):
        if (alt % 2) != 0:
            if Nsoufl_bas_gauche == True:

                if ((((N[savei + 1][savej - 1] == 2) & (M[savei + 1][savej - 1] == 2)) or (
                        (N[savei + 1][savej - 1] == 7) & (M[savei + 1][savej - 1] == 7))) & (M[savei][savej] != 3)):

                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")

                    M[savei + 1][savej + 1] = 1
                    Nsoufl_bas_gauche = False

                elif ((((N[savei + 1][savej - 1] == 2) & (M[savei + 1][savej - 1] == 2)) or (
                        (N[savei + 1][savej - 1] == 7) & (M[savei + 1][savej - 1] == 7))) & (M[savei][savej] == 3)):
                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                    M[savei][savej] = 1
                    Nsoufl_bas_gauche = False
                else:
                    pass

            elif Nsoufl_bas_droite == True:

                if ((((N[savei + 1][savej + 1] == 2) or (M[savei + 1][savej + 1] == 2)) or (
                        (N[savei + 1][savej + 1] == 7) & (M[savei + 1][savej + 1] == 7))) & (M[savei][savej] != 3)):

                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")

                    M[savei + 1][savej - 1] = 1
                    Nsoufl_bas_droite = False

                elif ((((N[savei + 1][savej + 1] == 2) & (M[savei + 1][savej + 1] == 2)) or (
                        (N[savei + 1][savej + 1] == 7) & (M[savei + 1][savej - +1] == 7))) & (M[savei][savej] == 3)):
                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                    M[savei][savej] = 1
                    Nsoufl_bas_droite = False
                else:
                    pass

            elif Nsoufl_haut_gauche == True:

                afficher(N)
                print()
                afficher(M)

                if ((((N[savei - 1][savej - 1] == 2) & (M[savei - 1][savej - 1] == 2)) or (
                        (N[savei - 1][savej - 1] == 7) & (M[savei - 1][savej - 1] == 7))) & (M[savei][savej] == 3)):
                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                    M[savei][savej] = 1
                    Nsoufl_haut_gauche = False

                elif ((((N[savei - 1][savej - 1] == 2) & (M[savei - 1][savej - 1] == 2)) or (
                        (N[savei - 1][savej - 1] == 7) & (M[savei - 1][savej - 1] == 7))) & (M[savei][savej] != 3)):

                    if (M[savei + 1][savej - 1] == 3):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei + 1][savej - 1] = 1
                        Nsoufl_haut_gauche = False

                    elif (M[savei + 1][savej + 1] == 3):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei + 1][savej + 1] = 1
                        Nsoufl_haut_gauche = False

                else:
                    pass

            elif Nsoufl_haut_droite == True:

                if ((((N[savei - 1][savej + 1] == 2) & (M[savei - 1][savej + 1] == 2)) or (
                        (N[savei - 1][savej + 1] == 7) & (M[savei - 1][savej + 1] == 7))) & (M[savei][savej] == 3)):
                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                    M[savei][savej] = 1
                    Nsoufl_haut_droite = False
                elif ((((N[savei - 1][savej + 1] == 2) & (M[savei - 1][savej + 1] == 2)) or (
                        (N[savei - 1][savej + 1] == 7) & (M[savei - 1][savej + 1] == 7))) & (M[savei][savej] != 3)):
                    if (M[savei + 1][savej + 1] == 3):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei + 1][savej + 1] = 1
                        Nsoufl_haut_droite = False

                    elif (M[savei + 1][savej - 1] == 3):
                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei + 1][savej - 1] = 1
                        Nsoufl_haut_droite = False
                else:
                    pass
            else:
                Nsoufl_bas_gauche = False
                Nsoufl_bas_droite = False
                Nsoufl_haut_droite = False
                Nsoufl_haut_gauche = False

            # Dame Noire :

            if DNsoufl_haut_droite == True:

                if (((N[savei - 1][savej + 1] == 2) or (N[savei - 1][savej + 1] == 7)) & (
                        (M[savei - 1][savej + 1] == 2) or (M[savei - 1][savej + 1] == 7)) & (M[savei][savej] != 8)):

                    # Possibilité 1/3 : 
                    if (M[savei - 1][savej - 1] == 8):

                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei - 1][savej - 1] = 1
                        DNsoufl_haut_droite = False

                    # Possibilité 2/3 :
                    elif (M[savei + 1][savej + 1] == 8):

                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei + 1][savej + 1] = 1
                        DNsoufl_haut_droite = False

                    # Possibilité 3/3 :
                    elif (M[savei + 1][savej - 1] == 8):

                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei + 1][savej - 1] = 1
                        DNsoufl_haut_droite = False

                elif (((N[savei - 1][savej + 1] == 2) or (N[savei - 1][savej + 1] == 7)) & (
                        (M[savei - 1][savej + 1] == 2) or (M[savei - 1][savej + 1] == 7)) & (M[savei][savej] == 8)):
                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                    M[savei][savej] = 1
                    DNsoufl_haut_droite = False
                else:
                    pass

            elif DNsoufl_haut_gauche == True:

                if (((N[savei - 1][savej - 1] == 2) or (N[savei - 1][savej - 1] == 7)) & (
                        (M[savei - 1][savej - 1] == 2) or (M[savei - 1][savej - 1] == 7)) & (M[savei][savej] != 8)):

                    # Possibilité 1/3 :
                    if (M[savei - 1][savej + 1] == 8):

                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei - 1][savej + 1] = 1
                        DNsoufl_haut_gauche = False

                    # Possibilité 2/3 :
                    elif (M[savei + 1][savej + 1] == 8):

                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei + 1][savej + 1] = 1
                        DNsoufl_haut_gauche = False

                    # Possibilité 3/3 :
                    elif (M[savei + 1][savej - 1] == 8):

                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei + 1][savej - 1] = 1
                        DNsoufl_haut_gauche = False

                elif (((N[savei - 1][savej - 1] == 2) or (N[savei - 1][savej - 1] == 7)) & (
                        (M[savei - 1][savej - 1] == 2) or (M[savei - 1][savej - 1] == 7)) & (M[savei][savej] == 8)):
                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                    M[savei][savej] = 1
                    DNsoufl_haut_gauche = False
                else:
                    pass

            elif DNsoufl_bas_droite == True:

                if (((N[savei + 1][savej + 1] == 2) or (N[savei + 1][savej + 1] == 7)) & (
                        (M[savei + 1][savej + 1] == 2) or (M[savei + 1][savej + 1] == 7)) & (M[savei][savej] == 8)):

                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                    M[savei][savej] = 1
                    DNsoufl_bas_droite = False

                elif (((N[savei + 1][savej + 1] == 2 or N[savei + 1][savej + 1] == 7)) & (
                        (M[savei + 1][savej + 1] == 2) or (M[savei + 1][savej + 1] == 7)) & (M[savei][savej] != 8)):

                    # Possibilité 1/3 : 
                    if (M[savei - 1][savej + 1] == 8):

                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei - 1][savej + 1] = 1
                        DNsoufl_bas_droite = False

                    # Possibilité 2/3 :
                    elif (M[savei - 1][savej - 1] == 8):

                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei - 1][savej - 1] = 1
                        DNsoufl_bas_droite = False

                    # Possibilité 3/3 :
                    elif (M[savei + 1][savej - 1] == 8):

                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei + 1][savej - 1] = 1
                        DNsoufl_bas_droite = False

                else:
                    pass

            elif DNsoufl_bas_gauche == True:

                if (((N[savei + 1][savej - 1] == 2) or (N[savei + 1][savej - 1] == 7)) & (
                        (M[savei + 1][savej - 1] == 2) or (M[savei + 1][savej - 1] == 7)) & (M[savei][savej] == 8)):
                    messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                    M[savei][savej] = 1
                    DNsoufl_bas_gauche = False

                elif (((N[savei + 1][savej - 1] == 2) or (N[savei + 1][savej - 1] == 7)) & (
                        (M[savei + 1][savej - 1] == 2) or (M[savei + 1][savej - 1] == 7)) & (M[savei][savej] != 8)):

                    # Possibilité 1/3 :
                    if (M[savei - 1][savej + 1] == 8):

                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei - 1][savej + 1] = 1
                        DNsoufl_bas_gauche = False

                    # Possibilité 2/3 :
                    elif (M[savei - 1][savej - 1] == 8):

                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei - 1][savej - 1] = 1
                        DNsoufl_bas_gauche = False

                    # Possibilité 3/3 :
                    elif (M[savei + 1][savej + 1] == 8):

                        messagebox.showinfo(title=None, message="ATTENTION : Un pion va être soufflé")
                        M[savei + 1][savej + 1] = 1
                        DNsoufl_bas_gauche = False
                else:
                    pass
            else:
                DNsoufl_bas_gauche = False
                DNsoufl_bas_droite = False
                DNsoufl_haut_droite = False
                DNsoufl_haut_gauche = False


def afficher(M):
    """
    Affiche une matrice en respectant les alignements par colonnes.
    Peut être utilisé pour observer la matrice à chaque nouvelle action.

    """
    w = [max([len(str(M[i][j])) for i in range(len(M))]) for j in range(len(M[0]))]
    for i in range(len(M)):
        for j in range(len(M[0])):
            print("%*s" % (w[j], str(M[i][j])), end=' ')
        print()


def matriceNulle(n, p):
    "Constructeur de matrice de dimensions données"
    M = []
    for i in range(n):
        L = []
        for j in range(p):
            L.append(10)
        M.append(L)
    return M


def ajout_col(M):
    n = 12
    N = matriceNulle(len(M) + 1, len(M[0]) + 1)

    for i in range(len(M)):
        N[i][len(N[0]) - 1] = 10

    for i in range(1, n - 1):

        for j in range(1, n - 1):

            if (i + j) % 2 == 0:
                N[i][j] = 0
            else:
                N[i][j] = 1

    for i in range(1, 5):

        for j in range(1, n - 1):
            if N[i][j] == 1:
                N[i][j] = 3

        for o in range(7, n - 1):

            for p in range(1, n - 1):

                if N[o][p] == 1:
                    N[o][p] = 2

    return N


def creation_plateau(n):
    " Créer une matrice correspondant au damier "
    M = matriceNulle(n, n)

    for i in range(1, n - 1):

        for j in range(1, n - 1):

            if (i + j) % 2 == 0:
                M[i][j] = 0
            else:
                M[i][j] = 1

    for i in range(1, 5):

        for j in range(1, n - 1):
            if M[i][j] == 1:
                M[i][j] = 3

        for o in range(7, n - 1):

            for p in range(1, n - 1):

                if M[o][p] == 1:
                    M[o][p] = 2

    return M


def siblanc(i, j, M):
    "Change la valeur de la case dans la matrice"

    M[i][j] = 5


def sinoir(i, j, M):
    "Change la valeur de la case dans la matrice"

    M[i][j] = 6


def siblancD(i, j, M):
    "Change la valeur de la case dans la matrice"

    M[i][j] = 11


def sinoirD(i, j, M):
    "Change la valeur de la case dans la matrice"

    M[i][j] = 12


def chevauchement():
    " Active le chevauchement "

    global chevaucher
    chevaucher = True


def chevauchement2():
    " Désactive le chevauchement "
    global chevaucher
    chevaucher = False


def damePlayT():
    global damePlay
    damePlay = True


def damePlayF():
    global damePlay
    damePlay = False


def detecDame(M):
    " Détecte si un pion ennemi arrive en fin de plateau et le transforme en dame "
    dame = False
    for j in range(1, 11):
        if M[1][j] == 2:
            dame = True
            M[1][j] = 7
    for j in range(1, 11):
        if M[10][j] == 3:
            dame = True
            M[10][j] = 8

    return dame


def dameBPLay(M, i, j):
    "Gestion du déplacement des dames Blanches"
    M[i][j] = 7

    if ((M[i - 1][j + 1] == 3) or (M[i - 1][j + 1] == 8)) and ((M[i - 2][j + 2] == 11)):
        M[i - 1][j + 1] = 1
        M[i - 2][j + 2] = 1



    elif ((M[i - 1][j - 1] == 3) or (M[i - 1][j - 1] == 8)) and ((M[i - 2][j - 2] == 11)):
        M[i - 1][j - 1] = 1
        M[i - 2][j - 2] = 1


    elif ((M[i + 1][j - 1] == 3) or (M[i + 1][j - 1] == 8)) and ((M[i + 2][j - 2] == 11)):
        M[i + 1][j - 1] = 1
        M[i + 2][j - 2] = 1


    elif ((M[i + 1][j + 1] == 3) or (M[i - +1][j + 1] == 8)) and ((M[i + 2][j + 2] == 11)):
        M[i + 1][j + 1] = 1
        M[i + 2][j + 2] = 1

    # Permet au dame de se déplacer :

    if (M[i + 1][j + 1] == 11):
        M[i + 1][j + 1] = 1

    elif ((M[i + 1][j - 1] == 11)):
        M[i + 1][j - 1] = 1

    elif ((M[i - 1][j - 1] == 11)):
        M[i - 1][j - 1] = 1

    elif ((M[i - 1][j + 1] == 11)):
        M[i - 1][j + 1] = 1


def dameNPLay(M, i, j):
    "Gestion du déplacement des dames Noires"
    M[i][j] = 8

    if (((M[i - 1][j + 1] == 2) or (M[i - 1][j + 1] == 7)) and (M[i - 2][j + 2] == 12)):
        M[i - 1][j + 1] = 1
        M[i - 2][j + 2] = 1


    elif (((M[i - 1][j - 1] == 2) or (M[i - 1][j - 1] == 7)) and (M[i - 2][j - 2] == 12)):
        M[i - 1][j - 1] = 1
        M[i - 2][j - 2] = 1


    elif (((M[i + 1][j - 1] == 2) or (M[i + 1][j - 1] == 7)) and (M[i + 2][j - 2] == 12)):
        M[i + 1][j - 1] = 1
        M[i + 2][j - 2] = 1


    elif (((M[i + 1][j + 1] == 2) or (M[i - +1][j + 1] == 7)) and (M[i + 2][j + 2] == 12)):
        M[i + 1][j + 1] = 1
        M[i + 2][j + 2] = 1

    # Permet au dame de se déplacer :

    if (M[i + 1][j + 1] == 12):
        M[i + 1][j + 1] = 1

    elif ((M[i + 1][j - 1] == 12)):
        M[i + 1][j - 1] = 1

    elif ((M[i - 1][j - 1] == 12)):
        M[i - 1][j - 1] = 1

    elif ((M[i - 1][j + 1] == 12)):
        M[i - 1][j + 1] = 1


def pionBplay(M, i, j):
    "Gestion du déplacement des pions Blancs"
    M[i][j] = 2
    detecDame(M)
    if ((M[i + 1][j - 1] == 3) or (M[i + 1][j - 1] == 8)) and ((M[i + 2][j - 2] == 5)):
        M[i + 1][j - 1] = 1
        M[i + 2][j - 2] = 1

    elif ((M[i + 1][j + 1] == 3) or (M[i + 1][j + 1] == 8)) and ((M[i + 2][j + 2] == 5)):
        M[i + 1][j + 1] = 1
        M[i + 2][j + 2] = 1

    # Permet au pions blanc de se déplacer (vers l'avant) :

    if (M[i + 1][j + 1] == 5):
        M[i + 1][j + 1] = 1

    elif ((M[i + 1][j - 1] == 5)):
        M[i + 1][j - 1] = 1


def pionNplay(M, i, j):
    "Gestion du déplacement des pions Noires"
    M[i][j] = 3
    detecDame(M)

    if ((M[i - 1][j + 1] == 2 or (M[i - 1][j + 1] == 7)) and (M[i - 2][j + 2] == 6)):
        M[i - 1][j + 1] = 1
        M[i - 2][j + 2] = 6
    elif ((M[i - 1][j - 1] == 2 or (M[i - 1][j - 1] == 7)) and (M[i - 2][j - 2] == 6)):
        M[i - 1][j - 1] = 1
        M[i - 2][j - 2] = 6

    # Permet au pions noirs de se déplacer (vers l'avant) :

    if (M[i - 1][j + 1] == 6):
        M[i - 1][j + 1] = 1
    elif ((M[i - 1][j - 1] == 6)):
        M[i - 1][j - 1] = 1


def chevaucB(M, i, j):
    "Gestion du chevauchement des pions Blancs"

    M[i][j] = 2

    detecDame(M)

    if ((M[i + 1][j - 1] == 3 or (M[i + 1][j - 1] == 8)) and (M[i + 2][j - 2] == 5)):
        M[i + 1][j - 1] = 1
        M[i + 2][j - 2] = 1

    elif ((M[i + 1][j + 1] == 3 or (M[i + 1][j + 1] == 8)) and (M[i + 2][j + 2] == 5)):
        M[i + 1][j + 1] = 1
        M[i + 2][j + 2] = 1

    if ((M[i - 1][j + 1] == 3 or (M[i - 1][j - 1] == 8)) and (M[i - 2][j + 2] == 5)):
        M[i - 1][j + 1] = 1
        M[i - 2][j + 2] = 1
    elif ((M[i - 1][j - 1] == 3 or (M[i - 1][j - 1] == 8)) and (M[i - 2][j - 2] == 5)):
        M[i - 1][j - 1] = 1
        M[i - 2][j - 2] = 1

    if (M[i + 1][j + 1] == 5):
        M[i + 1][j + 1] = 1
    elif ((M[i + 1][j - 1] == 5)):
        M[i + 1][j - 1] = 1


def chevauN(M, i, j):
    "Gestion du chevauchement des pions Noirs"
    M[i][j] = 3
    detecDame(M)

    if ((M[i - 1][j + 1] == 2 or (M[i - 1][j + 1] == 7)) and (M[i - 2][j + 2] == 6)):
        M[i - 1][j + 1] = 1
        M[i - 2][j + 2] = 1
    elif ((M[i - 1][j - 1] == 2 or (M[i - 1][j - 1] == 7)) and (M[i - 2][j - 2] == 6)):
        M[i - 1][j - 1] = 1
        M[i - 2][j - 2] = 1

    if ((M[i + 1][j - 1] == 2) or (M[i + 1][j - 1] == 7) and (M[i + 2][j - 2] == 6)):
        M[i + 1][j - 1] = 1
        M[i + 2][j - 2] = 1

    elif ((M[i + 1][j + 1] == 2) or (M[i + 1][j + 1] == 7)) and (M[i + 2][j + 2] == 6):
        M[i + 1][j + 1] = 1
        M[i + 2][j + 2] = 1

    if (M[i - 1][j + 1] == 6):
        M[i - 1][j + 1] = 1
    elif ((M[i - 1][j - 1] == 6)):
        M[i - 1][j - 1] = 1


def sicaseN(i, j, M, alt, p, app):
    "Change la valeur de la case dans la matrice, refresh le damier. Détermine le gagnant"
    global chevaucher, damePlay
    n = 12

    # Déplacement normal (chevauchement ou prise arrière) : 
    if chevaucher == False:

        # Si c'est le tour du joueur blanc : 
        if alt % 2 == 0:

            detecDame(M)

            # Permet au dame de prendre des pions :
            if damePlay == True:

                dameBPLay(M, i, j)

            # Permet au pions blanc de prendre des pions adverses (vers l'avant) :
            elif damePlay == False:

                pionBplay(M, i, j)


        # Si c'est le tour du joueur Noir : 
        elif alt % 2 != 0:

            detecDame(M)

            # Permet au dame de prendre des pions : 
            if damePlay == True:
                dameNPLay(M, i, j)


            # Permet au pions noirs de prendre des pions adverses (vers l'avant) : 
            elif damePlay == False:
                pionNplay(M, i, j)

    """ Gestion du chevauchement : """
    if chevaucher == True:

        """ Si c'est le tour du joueur blanc : """
        if alt % 2 == 0:

            chevaucB(M, i, j)


        # Si c'est le tour du joueur noir : 
        elif alt % 2 != 0:
            chevauN(M, i, j)

    """ Son de déplacement de pion :"""
    p.set_volume(1)
    p.play()

    """ Test si un des deux joueur n'as plus de pions : """
    wb = win_game_blc(M, n)
    wn = win_game_noir(M, n)

    """ Si un des deux joueur n'as plus de pions, affiche un message et active un son
        d'applaudissement :"""
    if wb == True:
        app.set_volume(0.6)
        app.play()
        messagebox.showinfo(title=None, message="Victoire des Blancs")

    else:
        pass

    if wn == True:
        app.set_volume(0.6)
        app.play()
        messagebox.showinfo(title=None, message="Victoire des Noirs")
    else:
        pass


def win_game_blc(damier, n):
    "test si les noirs on encore des pions"
    drapblanc = True
    for i in range(n):
        for j in range(n):
            if damier[i][j] == 3 or damier[i][j] == 12 or damier[i][j] == 8:
                drapblanc = False

    return drapblanc


def win_game_noir(damier, n):
    "Test si les blancs on encore des pions"
    drapNoir = True
    for i in range(n):
        for j in range(n):
            if damier[i][j] == 2 or damier[i][j] == 11 or damier[i][j] == 7:
                drapNoir = False

    return drapNoir


def on_closing(fen):
    " Permet de couper la musique quand on quitte la fenêtre "
    pygame.mixer.music.stop()
    fen.destroy()


#  A PARTIR DE CETTE LIGNE, LES FONCTIONS SUIVANTE CONCERNE LE BOT :
def dameDispoPriseBot(M):
    " Detecte si une dame à la possibilité de prendre un pion dans sa diagonale  : "

    cond = False

    m = 0
    k = 0
    maxi = 0
    maxj = 0
    count = 0

    for i in range(1, len(M) - 2):
        if cond: break
        for j in range(len(M[0]) - 2):

            if M[i][j] == 8:

                if M[i - 1][j + 1] == 1:

                    while (M[i - k][j + m] != 10):

                        if (M[i - k][j + m] == 1) or (M[i - k][j + m] == 6):

                            maxi = i - k
                            maxj = j + m
                            count += 1

                        elif (M[i - k][j + m] == 3):

                            break
                        elif M[i - k][j + m] == 2:

                            break
                        elif M[i - k][j + m] == 7:

                            break
                        m += 1
                        k += 1

    if (M[maxi - 1][maxj + 1] == 2) & (M[maxi - 2][maxj + 2] == 1):

        return True

    else:
        return False


def prisePionBOT(M, app, p):
    " Gère le BOT (Prise de pion,chevauchement, mouvement de pions,dame...) "

    liste = [-1, 1]
    find = False
    condition = False
    cond = True

    detecDame(M)

    # Dans un premier temps, le bot cherche dans tout le plateau si un pion est prenable,
    # si il en trouve un, il le prend et quitte la recherche. """

    while (find == False):

        for i in range(1, len(M) - 2):

            if condition: break
            for j in range(1, len(M[0]) - 2):

                # Gestion des DAMES:

                # On regarde si un dame a la possibilité de prendre un pion:

                # DIRECTION 1 : SI BAS GAUCHE PRENABLE, TEST SI ELLE PEUT CHEVAUCHER D'AUTRE PIONS .
                if (M[i][j] == 8) & (i <= 10) & (
                        M[i - 1][j - 1] == 2 or M[i - 1][j - 1] == 5 or M[i - 1][j - 1] == 7 or M[i - 1][
                    j - 1] == 11) & (M[i - 2][j - 2] == 1 or M[i - 2][j - 2] == 6):
                    M[i][j] = 1
                    M[i - 1][j - 1] = 1
                    M[i - 2][j - 2] = 8
                    detecDame(M)

                    if ((M[i - 3][j - 1] == 2 or M[i - 3][j - 1] == 7) & (
                            (M[i - 4][j] == 1) or (M[i - 4][j] == 6) or (M[i - 4][j] == 5) or (M[i - 4][j] == 11))):
                        M[i - 3][j - 1] = 1
                        M[i - 2][j - 2] = 1
                        M[i - 4][j] = 8

                        if ((M[i - 3][j + 1] == 2 or M[i - 3][j + 1] == 7) & (
                                (M[i - 2][j + 2] == 1) or (M[i - 2][j + 2] == 6) or (M[i - 2][j + 2] == 5)) or (
                                M[i - 2][j + 2] == 11)):
                            M[i - 2][j + 2] = 8
                            M[i - 3][j + 1] = 1
                            M[i - 4][j] = 1

                            find = True
                            condition = True
                            detecDame(M)
                            break

                        find = True
                        condition = True
                        detecDame(M)
                        break

                    if ((M[i - 1][j - 3] == 2 or M[i - 1][j - 3] == 7) & (
                            (M[i][j - 4] == 1) or (M[i][j - 4] == 6) or (M[i][j - 4] == 5))):
                        M[i - 1][j - 3] = 1
                        M[i - 2][j - 2] = 1
                        M[i][j - 4] = 8

                        if ((M[i + 1][j - 3] == 2 or M[i + 1][j - 3] == 7) & (
                                (M[i + 2][j - 2] == 1) or (M[i + 2][j - 2] == 6) or (M[i + 2][j - 2] == 5))):
                            M[i + 2][j - 2] = 8
                            M[i + 1][j - 3] = 1
                            M[i][j - 4] = 1

                            find = True
                            condition = True
                            detecDame(M)
                            break

                        find = True
                        condition = True
                        detecDame(M)
                        break

                    if ((M[i - 3][j - 3] == 2 or M[i - 3][j - 3] == 7) & (
                            (M[i - 4][j - 4] == 1) or (M[i - 4][j - 4] == 6) or (M[i - 4][j - 4] == 5))):
                        M[i - 3][j - 3] = 1
                        M[i - 2][j - 2] = 1
                        M[i - 4][j - 4] = 8

                        if ((M[i - 5][j - 5] == 2 or M[i - 5][j - 5] == 7) & (
                                (M[i - 6][j - 6] == 1) or (M[i - 6][j - 6] == 6) or (M[i - 6][j - 6] == 5))):
                            M[i - 5][j - 5] = 1
                            M[i - 4][j - 4] = 1
                            M[i - 6][j - 6] = 8
                            find = True
                            condition = True
                            detecDame(M)
                            break

                    find = True
                    condition = True
                    break
                ########################################################################################################
                # DIRECTION 2 : SI BAS DROITE PRENABLE, TEST SI ELLE PEUT CHEVAUCHER D'AUTRE PIONS .
                elif (M[i][j] == 8) & (M[i - 1][j + 1] == 2 or M[i - 1][j + 1] == 5 or M[i - 1][j + 1] == 7 or M[i - 1][
                    j + 1] == 11) & (M[i - 2][j + 2] == 1 or M[i - 2][j + 2] == 6):
                    M[i][j] = 1
                    M[i - 1][j + 1] = 1
                    M[i - 2][j + 2] = 8
                    detecDame(M)

                    # SOUS DIRECTION 1 :
                    if ((M[i - 1][j + 3] == 2 or M[i - 1][j + 3] == 7) & (
                            (M[i][j + 4] == 1) or (M[i][j + 4] == 6) or (M[i][j + 4] == 5))):
                        M[i - 1][j + 3] = 1
                        M[i - 2][j + 2] = 1
                        M[i][j + 4] = 8

                        # SOUS SOUS DIRECTION :
                        if ((M[i + 1][j + 3] == 2 or M[i + 1][j + 3] == 7) & (
                                (M[i + 2][j + 2] == 1) or (M[i + 2][j + 2] == 6) or (M[i + 2][j + 2] == 5))):
                            M[i + 1][j + 3] = 1
                            M[i + 2][j + 2] = 8
                            M[i][j + 4] = 1

                            find = True
                            condition = True
                            detecDame(M)
                            break

                        find = True
                        condition = True
                        detecDame(M)
                        break

                    # SOUS DIRECTION 2 :
                    if ((M[i - 3][j + 1] == 2 or M[i - 3][j + 1] == 7) & (
                            (M[i - 4][j] == 1) or (M[i - 4][j] == 6) or (M[i - 4][j] == 5))):
                        M[i - 3][j + 1] = 1
                        M[i - 2][j + 2] = 1
                        M[i - 4][j] = 8

                        # SOUS SOUS DIRECTION :
                        if ((M[i - 3][j - 1] == 2 or M[i - 3][j - 1] == 7) & (
                                (M[i - 2][j - 2] == 1) or (M[i - 2][j - 2] == 6) or (M[i - 2][j - 2] == 5))):
                            M[i - 3][j - 1] = 1
                            M[i - 2][j - 2] = 8
                            M[i - 4][j] = 1

                            find = True
                            condition = True
                            detecDame(M)
                            break

                        find = True
                        condition = True
                        detecDame(M)
                        break

                    # SOUS DIRECTION 3 :
                    if ((M[i - 3][j + 3] == 2 or M[i - 3][j + 3] == 7) & (
                            (M[i - 4][j + 4] == 1) or (M[i - 4][j + 4] == 6) or (M[i - 4][j + 4] == 5))):
                        M[i - 3][j + 3] = 1
                        M[i - 2][j + 2] = 1
                        M[i - 4][j + 4] = 8

                        # SOUS SOUS DIRECTION :
                        if ((M[i - 5][j + 5] == 2 or M[i - 5][j + 5] == 7) & (
                                (M[i - 6][j + 6] == 1) or (M[i - 6][j + 6] == 6) or (M[i - 6][j + 6] == 5))):
                            M[i - 5][j + 5] = 1
                            M[i - 4][j + 4] = 1
                            M[i - 6][j + 6] = 8
                            find = True
                            condition = True
                            detecDame(M)
                            break

                    find = True
                    condition = True
                    break
                ########################################################################################################
                # DIRECTION 3 : SI HAUT GAUCHE PRENABLE, TEST SI ELLE PEUT CHEVAUCHER D'AUTRE PIONS .
                elif (M[i][j] == 8) & (M[i + 1][j - 1] == 2 or M[i + 1][j - 1] == 5 or M[i + 1][j - 1] == 7 or M[i + 1][
                    j - 1] == 11) & (M[i + 2][j - 2] == 1 or M[i + 2][j - 2] == 6):
                    M[i][j] = 1
                    M[i + 1][j - 1] = 1
                    M[i + 2][j - 2] = 8
                    detecDame(M)

                    # SOUS DIRECTION 1 :
                    if M[i + 2][j - 2] != 8:
                        if ((M[i + 3][j - 1] == 2 or M[i + 3][j - 1] == 7) & (
                                (M[i + 4][j] == 1) or (M[i + 4][j] == 6) or (M[i + 4][j] == 5))):
                            M[i + 2][j - 2] = 1
                            M[i + 3][j - 1] = 1
                            M[i + 4][j] = 8

                            # SOUS SOUS DIRECTION :
                            if ((M[i + 3][j + 1] == 2 or M[i + 3][j + 1] == 7) & (
                                    (M[i + 2][j + 2] == 1) or (M[i + 2][j + 2] == 6) or (M[i + 2][j + 2] == 5))):
                                M[i + 2][j + 2] = 8
                                M[i + 3][j + 1] = 1
                                M[i + 4][j] = 1

                                find = True
                                condition = True
                                detecDame(M)
                                break

                            find = True
                            condition = True
                            detecDame(M)
                            break

                        # SOUS DIRECTION 2 :
                        if ((M[i + 1][j - 3] == 2 or M[i + 1][j - 3] == 7) & (
                                (M[i][j - 4] == 1) or (M[i][j - 4] == 6) or (M[i][j - 4] == 5))):
                            M[i + 2][j - 2] = 1
                            M[i + 1][j - 3] = 1
                            M[i][j - 4] = 8

                            # SOUS SOUS DIRECTION :
                            if ((M[i - 1][j - 3] == 2 or M[i - 1][j - 3] == 7) & (
                                    (M[i - 2][j - 2] == 1) or (M[i - 2][j - 2] == 6) or (M[i - 2][j - 2] == 5))):
                                M[i - 2][j - 2] = 8
                                M[i - 1][j - 3] = 1
                                M[i][j - 4] = 1

                                find = True
                                condition = True
                                detecDame(M)
                                break

                            find = True
                            condition = True
                            detecDame(M)
                            break

                        # SOUS DIRECTION 3 :
                        if ((M[i + 3][j - 3] == 2 or M[i + 3][j - 3] == 7) & (
                                (M[i + 4][j - 4] == 1) or (M[i + 4][j - 4] == 6) or (M[i + 4][j - 4] == 5))):
                            M[i + 2][j - 2] = 1
                            M[i + 3][j - 3] = 1
                            M[i + 4][j - 4] = 8

                            # SOUS SOUS DIRECTION :
                            if ((M[i + 5][j - 5] == 2 or M[i + 5][j - 5] == 7) & (
                                    (M[i + 6][j - 6] == 1) or (M[i + 6][j - 6] == 6) or (M[i + 6][j - 6] == 5))):
                                M[i + 5][j - 5] = 1
                                M[i + 4][j - 4] = 1
                                M[i + 6][j - 6] = 8
                                find = True
                                condition = True
                                detecDame(M)
                                break

                    find = True
                    condition = True
                    break

                ########################################################################################################
                # DIRECTION 4 : SI BAS DROITE PRENABLE, TEST SI ELLE PEUT CHEVAUCHER D'AUTRE PIONS .
                elif (M[i][j] == 8) & (M[i + 1][j + 1] == 2 or M[i + 1][j + 1] == 5 or M[i + 1][j + 1] == 7 or M[i + 1][
                    j + 1] == 11) & (M[i + 2][j + 2] == 1 or M[i + 2][j + 2] == 6):
                    M[i][j] = 1
                    M[i + 1][j + 1] = 1
                    M[i + 2][j + 2] = 8
                    detecDame(M)

                    # SOUS DIRECTION 1 :
                    if M[i + 2][j + 2] != 8:
                        if ((M[i + 1][j + 3] == 2 or M[i + 1][j + 3] == 7) & (
                                (M[i][j + 4] == 1) or (M[i][j + 4] == 6) or (M[i][j + 4] == 5))):
                            M[i + 2][j + 2] = 1
                            M[i + 1][j + 3] = 1
                            M[i][j + 4] = 8

                            # SOUS SOUS DIRECTION :
                            if ((M[i - 1][j + 3] == 2 or M[i - 1][j + 3] == 7) & (
                                    (M[i - 2][j + 2] == 1) or (M[i - 2][j + 2] == 6) or (M[i - 2][j + 2] == 5))):
                                M[i][j + 4] = 1
                                M[i - 1][j + 3] = 1
                                M[i - 2][j + 2] = 8

                                find = True
                                condition = True
                                detecDame(M)
                                break

                            find = True
                            condition = True
                            detecDame(M)
                            break

                        # SOUS DIRECTION 2 :
                        if ((M[i + 3][j + 1] == 2 or M[i + 3][j + 1] == 7) & (
                                (M[i + 4][j] == 1) or (M[i + 4][j] == 6) or (M[i + 4][j] == 5))):
                            M[i + 2][j + 2] = 1
                            M[i + 3][j + 1] = 1
                            M[i + 4][j] = 8

                            # SOUS SOUS DIRECTION :
                            if ((M[i + 3][j - 1] == 2 or M[i + 3][j - 1] == 7) & (
                                    (M[i + 2][j - 2] == 1) or (M[i + 2][j - 2] == 6) or (M[i + 2][j - 2] == 5))):
                                M[i + 4][j] = 1
                                M[i + 3][j - 1] = 1
                                M[i + 2][j - 2] = 8

                                find = True
                                condition = True
                                detecDame(M)
                                break

                            find = True
                            condition = True
                            detecDame(M)
                            break

                        # SOUS DIRECTION 3 :
                        if ((M[i + 3][j + 3] == 2 or M[i + 3][j + 3] == 7) & (
                                (M[i + 4][j + 4] == 1) or (M[i + 4][j + 4] == 6) or (M[i + 4][j + 4] == 5))):
                            M[i + 2][j + 2] = 1
                            M[i + 3][j + 3] = 1
                            M[i + 4][j + 4] = 8

                            # SOUS SOUS DIRECTION :
                            if ((M[i + 5][j + 5] == 2 or M[i + 5][j + 5] == 7) & (
                                    (M[i + 6][j + 6] == 1) or (M[i + 6][j + 6] == 6) or (M[i + 6][j + 6] == 5))):
                                M[i + 5][j + 5] = 1
                                M[i + 4][j + 4] = 1
                                M[i + 6][j + 6] = 8

                                find = True
                                condition = True
                                detecDame(M)
                                break

                    find = True
                    condition = True

                    break

                    # Pions :
                ########################################################################################################
                # Pour les pions : Fonctionne de la même manière que les DAMES.

                if (M[i][j] == 3) & (M[i + 1][j + 1] == 2 or M[i + 1][j + 1] == 7) & (
                        M[i + 2][j + 2] == 1 or M[i + 2][j + 2] == 6):

                    M[i][j] = 1
                    M[i + 1][j + 1] = 1
                    M[i + 2][j + 2] = 3
                    detecDame(M)

                    # SOUS DIRECTION 1 :
                    if M[i + 2][j + 2] != 8:
                        if ((M[i + 1][j + 3] == 2 or M[i + 1][j + 3] == 7) & (
                                (M[i][j + 4] == 1) or (M[i][j + 4] == 6) or (M[i][j + 4] == 5) or (M[i][j + 4] == 7))):
                            M[i + 2][j + 2] = 1
                            M[i + 1][j + 3] = 1
                            M[i][j + 4] = 3

                            # SOUS SOUS DIRECTION :
                            if ((M[i - 1][j + 3] == 2 or M[i - 1][j + 3] == 7) & (
                                    (M[i - 2][j + 2] == 1) or (M[i - 2][j + 2] == 6) or (M[i - 2][j + 2] == 5) or (
                                    M[i - 2][j + 2] == 7))):
                                M[i][j + 4] = 1
                                M[i - 1][j + 3] = 1
                                M[i - 2][j + 2] = 3

                                find = True
                                condition = True
                                detecDame(M)
                                break

                            find = True
                            condition = True
                            detecDame(M)
                            break

                        # SOUS DIRECTION 2 :
                        if ((M[i + 3][j + 1] == 2 or M[i + 3][j + 1] == 7) & (
                                (M[i + 4][j] == 1) or (M[i + 4][j] == 6) or (M[i + 4][j] == 5) or (M[i + 4][j] == 7))):
                            M[i + 2][j + 2] = 1
                            M[i + 3][j + 1] = 1
                            M[i + 4][j] = 3

                            # SOUS SOUS DIRECTION :
                            if ((M[i + 3][j - 1] == 2 or M[i + 3][j - 1] == 7) & (
                                    (M[i + 2][j - 2] == 1) or (M[i + 2][j - 2] == 6) or (M[i + 2][j - 2] == 5) or (
                                    M[i + 2][j - 2] == 7))):
                                M[i + 4][j] = 1
                                M[i + 3][j - 1] = 1
                                M[i + 2][j - 2] = 3

                                find = True
                                condition = True
                                detecDame(M)
                                break

                            find = True
                            condition = True
                            detecDame(M)
                            break

                        # SOUS DIRECTION 3 :
                        if ((M[i + 3][j + 3] == 2 or M[i + 3][j + 3] == 7) & (
                                (M[i + 4][j + 4] == 1) or (M[i + 4][j + 4] == 6) or (M[i + 4][j + 4] == 5) or (
                                M[i + 4][j + 4] == 7))):
                            M[i + 2][j + 2] = 1
                            M[i + 3][j + 3] = 1
                            M[i + 4][j + 4] = 3

                            # SOUS SOUS DIRECTION :
                            if ((M[i + 5][j + 5] == 2 or M[i + 5][j + 5] == 7) & (
                                    (M[i + 6][j + 6] == 1) or (M[i + 6][j + 6] == 6) or (M[i + 6][j + 6] == 5) or (
                                    M[i + 6][j + 6] == 7))):
                                M[i + 5][j + 5] = 1
                                M[i + 4][j + 4] = 1
                                M[i + 6][j + 6] = 3

                                find = True
                                condition = True
                                detecDame(M)
                                break

                    find = True
                    condition = True
                    detecDame(M)
                    break

                ########################################################################################################
                elif (M[i][j] == 3) & (M[i + 1][j - 1] == 2 or M[i + 1][j - 1] == 7) & (
                        M[i + 2][j - 2] == 1 or M[i + 2][j - 2] == 6):

                    M[i][j] = 1
                    M[i + 1][j - 1] = 1
                    M[i + 2][j - 2] = 3
                    detecDame(M)

                    # SOUS DIRECTION 1 :
                    if M[i + 2][j - 2] != 8:
                        if ((M[i + 3][j - 1] == 2 or M[i + 3][j - 1] == 7) & (
                                (M[i + 4][j] == 1) or (M[i + 4][j] == 6) or (M[i + 4][j] == 5)) or (M[i + 4][j] == 7)):
                            M[i + 2][j - 2] = 1
                            M[i + 3][j - 1] = 1
                            M[i + 4][j] = 3

                            # SOUS SOUS DIRECTION :
                            if ((M[i + 3][j + 1] == 2 or M[i + 3][j + 1] == 7) & (
                                    (M[i + 2][j + 2] == 1) or (M[i + 2][j + 2] == 6) or (M[i + 2][j + 2] == 5)) or (
                                    M[i + 2][j + 2] == 7)):
                                M[i + 2][j + 2] = 3
                                M[i + 3][j + 1] = 1
                                M[i + 4][j] = 1

                                find = True
                                condition = True
                                detecDame(M)
                                break

                            find = True
                            condition = True
                            detecDame(M)
                            break

                        # SOUS DIRECTION 2 :
                        if ((M[i + 1][j - 3] == 2 or M[i + 1][j - 3] == 7) & (
                                (M[i][j - 4] == 1) or (M[i][j - 4] == 6) or (M[i][j - 4] == 5) or (M[i][j - 4] == 7))):
                            M[i + 2][j - 2] = 1
                            M[i + 1][j - 3] = 1
                            M[i][j - 4] = 3

                            # SOUS SOUS DIRECTION :
                            if ((M[i - 1][j - 3] == 2 or M[i - 1][j - 3] == 7) & (
                                    (M[i - 2][j - 2] == 1) or (M[i - 2][j - 2] == 6) or (M[i - 2][j - 2] == 5)) or (
                                    M[i - 2][j - 2] == 7)):
                                M[i - 2][j - 2] = 3
                                M[i - 1][j - 3] = 1
                                M[i][j - 4] = 1

                                find = True
                                condition = True
                                detecDame(M)
                                break

                            find = True
                            condition = True
                            detecDame(M)
                            break

                        # SOUS DIRECTION 3 :
                        if ((M[i + 3][j - 3] == 2 or M[i + 3][j - 3] == 7) & (
                                (M[i + 4][j - 4] == 1) or (M[i + 4][j - 4] == 6) or (M[i + 4][j - 4] == 5) or (
                                M[i + 4][j - 4] == 7))):
                            M[i + 2][j - 2] = 1
                            M[i + 3][j - 3] = 1
                            M[i + 4][j - 4] = 3

                            # SOUS SOUS DIRECTION :
                            if ((M[i + 5][j - 5] == 2 or M[i + 5][j - 5] == 7) & (
                                    (M[i + 6][j - 6] == 1) or (M[i + 6][j - 6] == 6) or (M[i + 6][j - 6] == 5) or (
                                    M[i + 6][j - 6] == 7))):
                                M[i + 5][j - 5] = 1
                                M[i + 4][j - 4] = 1
                                M[i + 6][j - 6] = 3
                                find = True
                                condition = True
                                detecDame(M)
                                break

                    find = True
                    condition = True
                    detecDame(M)

                    break
                ########################################################################################################
                elif (M[i][j] == 3) & (M[i - 1][j - 1] == 2 or M[i - 1][j - 1] == 7) & (
                        M[i - 2][j - 2] == 1 or M[i - 2][j - 2] == 6):

                    M[i][j] = 1
                    M[i - 1][j - 1] = 1
                    M[i - 2][j - 2] = 3
                    detecDame(M)

                    # SOUS DIRECTION 1 :
                    if ((M[i - 3][j - 1] == 2 or M[i - 3][j - 1] == 7) & (
                            (M[i - 4][j] == 1) or (M[i - 4][j] == 6) or (M[i - 4][j] == 5) or (M[i - 4][j] == 7))):
                        M[i - 3][j - 1] = 1
                        M[i - 2][j - 2] = 1
                        M[i - 4][j] = 3

                        # SOUS SOUS DIRECTION :
                        if ((M[i - 3][j + 1] == 2 or M[i - 3][j + 1] == 7) & (
                                (M[i - 2][j + 2] == 1) or (M[i - 2][j + 2] == 6) or (M[i - 2][j + 2] == 5)) or (
                                M[i - 2][j + 2] == 7)):
                            M[i - 2][j + 2] = 3
                            M[i - 3][j + 1] = 1
                            M[i - 4][j] = 1

                            find = True
                            condition = True
                            detecDame(M)
                            break

                        find = True
                        condition = True
                        detecDame(M)
                        break

                    # SOUS DIRECTION 2 :
                    if ((M[i - 1][j - 3] == 2 or M[i - 1][j - 3] == 7) & (
                            (M[i][j - 4] == 1) or (M[i][j - 4] == 6) or (M[i][j - 4] == 5) or (M[i][j - 4] == 7))):
                        M[i - 1][j - 3] = 1
                        M[i - 2][j - 2] = 1
                        M[i][j - 4] = 3

                        # SOUS SOUS DIRECTION :
                        if ((M[i + 1][j - 3] == 2 or M[i + 1][j - 3] == 7) & (
                                (M[i + 2][j - 2] == 1) or (M[i + 2][j - 2] == 6) or (M[i + 2][j - 2] == 5)) or (
                                M[i + 2][j - 2] == 7)):
                            M[i + 2][j - 2] = 3
                            M[i + 1][j - 3] = 1
                            M[i][j - 4] = 1

                            find = True
                            condition = True
                            detecDame(M)
                            break

                        find = True
                        condition = True
                        detecDame(M)
                        break

                    # SOUS DIRECTION 3 :
                    if ((M[i - 3][j - 3] == 2 or M[i - 3][j - 3] == 7) & (
                            (M[i - 4][j - 4] == 1) or (M[i - 4][j - 4] == 6) or (M[i - 4][j - 4] == 5) or (
                            M[i - 4][j - 4] == 7))):
                        M[i - 3][j - 3] = 1
                        M[i - 2][j - 2] = 1
                        M[i - 4][j - 4] = 3

                        # SOUS SOUS DIRECTION :
                        if ((M[i - 5][j - 5] == 2 or M[i - 5][j - 5] == 7) & (
                                (M[i - 6][j - 6] == 1) or (M[i - 6][j - 6] == 6) or (M[i - 6][j - 6] == 5) or (
                                M[i - 6][j - 6] == 7))):
                            M[i - 5][j - 5] = 1
                            M[i - 4][j - 4] = 1
                            M[i - 6][j - 6] = 3
                            find = True
                            condition = True
                            detecDame(M)
                            break

                    find = True
                    condition = True
                    detecDame(M)
                    break
                ########################################################################################################
                elif (M[i][j] == 3) & (M[i - 1][j + 1] == 2 or M[i - 1][j + 1] == 7) & (
                        M[i - 2][j + 2] == 1 or M[i - 2][j + 2] == 6):
                    M[i][j] = 1
                    M[i - 1][j + 1] = 1
                    M[i - 2][j + 2] = 3
                    detecDame(M)

                    # SOUS DIRECTION 1 :
                    if ((M[i - 1][j + 3] == 2 or M[i - 1][j + 3] == 7) & (
                            (M[i][j + 4] == 1) or (M[i][j + 4] == 6) or (M[i][j + 4] == 5) or (M[i][j + 4] == 7))):
                        M[i - 1][j + 3] = 1
                        M[i - 2][j + 2] = 1
                        M[i][j + 4] = 3

                        # SOUS SOUS DIRECTION :
                        if ((M[i + 1][j + 3] == 2 or M[i + 1][j + 3] == 7) & (
                                (M[i + 2][j + 2] == 1) or (M[i + 2][j + 2] == 6) or (M[i + 2][j + 2] == 5) or (
                                M[i + 2][j + 2] == 7))):
                            M[i + 1][j + 3] = 1
                            M[i + 2][j + 2] = 3
                            M[i][j + 4] = 1

                            find = True
                            condition = True
                            detecDame(M)
                            break

                        find = True
                        condition = True
                        detecDame(M)
                        break

                    # SOUS DIRECTION 2 :
                    if ((M[i - 3][j + 1] == 2 or M[i - 3][j + 1] == 7) & (
                            (M[i - 4][j] == 1) or (M[i - 4][j] == 6) or (M[i - 4][j] == 5) or (M[i - 4][j] == 7))):
                        M[i - 3][j + 1] = 1
                        M[i - 2][j + 2] = 1
                        M[i - 4][j] = 3

                        # SOUS SOUS DIRECTION :
                        if ((M[i - 3][j - 1] == 2 or M[i - 3][j - 1] == 7) & (
                                (M[i - 2][j - 2] == 1) or (M[i - 2][j - 2] == 6) or (M[i - 2][j - 2] == 5) or (
                                M[i - 2][j - 2] == 7))):
                            M[i - 3][j - 1] = 1
                            M[i - 2][j - 2] = 3
                            M[i - 4][j] = 1

                            find = True
                            condition = True
                            detecDame(M)
                            break

                        find = True
                        condition = True
                        detecDame(M)
                        break

                    # SOUS DIRECTION 3 :
                    if ((M[i - 3][j + 3] == 2 or M[i - 3][j + 3] == 7) & (
                            (M[i - 4][j + 4] == 1) or (M[i - 4][j + 4] == 6) or (M[i - 4][j + 4] == 5) or (
                            M[i - 4][j + 4] == 7))):
                        M[i - 3][j + 3] = 1
                        M[i - 2][j + 2] = 1
                        M[i - 4][j + 4] = 3

                        # SOUS SOUS DIRECTION :
                        if ((M[i - 5][j + 5] == 2 or M[i - 5][j + 5] == 7) & (
                                (M[i - 6][j + 6] == 1) or (M[i - 6][j + 6] == 6) or (M[i - 6][j + 6] == 5) or (
                                M[i - 6][j + 6] == 7))):
                            M[i - 5][j + 5] = 1
                            M[i - 4][j + 4] = 1
                            M[i - 6][j + 6] = 3
                            find = True
                            condition = True
                            detecDame(M)
                            break

                    detecDame(M)
                    find = True
                    condition = True

                    break
        ########################################################################################################
        # Dans un second temps, si le bot n'as pas trouvé de pion à prendre,
        # il va chosir aléatoirement un de ses pions/dames et le/la déplacer de une case ou sur une diagonale pour les dames. 

        while (cond == True) & (find == False):

            i = randint(1, 10)
            j = randint(1, 10)

            # Dames :
            if M[i][j] == 8:

                trouver = False
                dispo1 = False
                dispo2 = False
                dispo3 = False
                dispo4 = False

                while (trouver == False):

                    # On détecte si un obstacle se situe sur chaque diagonale. On incrémente de 1 un compteur de case vide.
                    # On note la case maximale à laquelle la dame peut se déplacer et on met une variable "dispo" a True lorsque
                    # une dame a la possiblité de ce déplacer sur une diagonale.
                    # On répète l'opération pour les 4 diagonales :
                    m = 0
                    k = 0
                    maxi1 = 0
                    maxj1 = 0
                    count = 0

                    while (M[i - k][j + m] != 10):

                        if (M[i - k - 1][j + m + 1] == 8):
                            break
                        if (M[i - k][j + m] == 1) or (M[i - k][j + m] == 6):
                            dispo1 = True
                            trouver = True
                            maxi1 = i - k
                            maxj1 = j + m
                            count += 1
                        elif (M[i - k][j + m] == 3):

                            break
                        elif M[i - k][j + m] == 2:

                            break
                        elif M[i - k][j + m] == 7:

                            break
                        m += 1
                        k += 1

                    if (maxj1 == 0) & (maxi1 == 0):
                        dispo1 = False

                    m = 0
                    k = 0
                    maxi2 = 0
                    maxj2 = 0
                    count2 = 0

                    while (M[i - k][j - m] != 10):

                        if (M[i - k - 1][j - m - 1] == 8):
                            break
                        if (M[i - k][j - m] == 1) or (M[i - k][j - m] == 6):
                            dispo2 = True
                            trouver = True
                            maxi2 = i - k
                            maxj2 = j - m
                            count2 += 1
                        elif (M[i - k][j - m] == 3):

                            break
                        elif M[i - k][j - m] == 2:

                            break
                        elif M[i - k][j - m] == 7:

                            break
                        m += 1
                        k += 1

                    if (maxj2 == 0) & (maxi2 == 0):
                        dispo2 = False

                    m = 0
                    k = 0
                    maxi3 = 0
                    maxj3 = 0
                    count3 = 0

                    while (M[i + k][j - m] != 10):
                        if (M[i + k + 1][j - m - 1] == 8):
                            break

                        if (M[i + k][j - m] == 1) or (M[i + k][j - m] == 6):
                            dispo3 = True
                            trouver = True
                            maxi3 = i + k
                            maxj3 = j - m
                            count3 += 1
                        elif (M[i + k][j - m] == 3):

                            break
                        elif M[i + k][j - m] == 2:

                            break
                        elif M[i + k][j - m] == 7:
                            break
                        m += 1
                        k += 1

                    if (maxj3 == 0) & (maxi3 == 0):
                        dispo3 = False

                    m = 0
                    k = 0
                    maxi4 = 0
                    maxj4 = 0
                    count4 = 0

                    while (M[i + k][j + m] != 10):
                        if (M[i + k + 1][j + m + 1] == 8):
                            break

                        if (M[i + k][j + m] == 1) or (M[i + k][j + m] == 6):
                            dispo4 = True
                            trouver = True
                            maxi4 = i + k
                            maxj4 = j + m
                            count4 += 1
                        elif (M[i + k][j + m] == 3):

                            break
                        elif M[i + k][j + m] == 2:

                            break
                        elif M[i + k][j + m] == 7:

                            break
                        m += 1
                        k += 1

                    if (maxj4 == 0) & (maxi4 == 0):
                        dispo4 = False

                # Déplace une dame sur un diagonale choisi au hasars si disponible.

                if (dispo1 == True) & (dispo2 == True) & (dispo3 == True) & (dispo4 == True):
                    choice = randint(1, 4)

                    # Si les 4 diagonale sont disponibles ont en choisi une au hasard :
                    if choice == 1:
                        topDroite(M, i, j, maxi1, maxj1, count, app, p)
                        find = True
                        cond = False

                    elif choice == 2:
                        topLeft(M, i, j, maxi2, maxj2, count2, app, p)
                        find = True
                        cond = False

                    elif choice == 3:
                        basLeft(M, i, j, maxi3, maxj3, count3, app, p)
                        find = True
                        cond = False

                    elif choice == 4:
                        basDroite(M, i, j, maxi4, maxj4, count4, app, p)
                        find = True
                        cond = False

                elif (dispo1 == True) & (dispo2 == True):
                    choice = randint(1, 2)
                    #  Si les deux diagonale vers le haut sont disponibles, ont en choisi une au hasard.

                    if choice == 1:
                        topDroite(M, i, j, maxi1, maxj1, count, app, p)
                        find = True
                        cond = False

                    elif choice == 2:
                        topLeft(M, i, j, maxi2, maxj2, count2, app, p)
                        find = True
                        cond = False

                elif (dispo3 == True) & (dispo4 == True):
                    choice = randint(1, 2)
                    # Comme si dessus mais pour les diagonales BAS.

                    if choice == 1:
                        basDroite(M, i, j, maxi4, maxj4, count4, app, p)
                        find = True
                        cond = False

                    elif choice == 2:
                        basLeft(M, i, j, maxi3, maxj3, count3, app, p)
                        find = True
                        cond = False

                # Sinon on choisi celle dispo.
                elif dispo1 == True:
                    topDroite(M, i, j, maxi1, maxj1, count, app, p)
                    find = True
                    cond = False

                elif dispo2 == True:
                    topLeft(M, i, j, maxi2, maxj2, count2, app, p)
                    find = True
                    cond = False

                elif dispo3 == True:
                    basLeft(M, i, j, maxi3, maxj3, count3, app, p)
                    find = True
                    cond = False

                elif dispo4 == True:
                    basDroite(M, i, j, maxi4, maxj4, count4, app, p)
                    find = True
                    cond = False

            # Pions :

            if (M[i][j] == 3) & ((M[i + 1][j + 1] == 1) & (M[i + 1][j - 1] == 1)):
                M[i][j] = 1
                M[i + 1][j + liste[randint(0, 1)]] = 3

                find = True
                cond = False
                detecDame(M)

            elif (M[i][j] == 3) & (M[i + 1][j + 1] == 1 or M[i + 1][j + 1] == 6):
                M[i][j] = 1
                M[i + 1][j + 1] = 3

                find = True
                cond = False
                detecDame(M)

            elif (M[i][j] == 3) & (M[i + 1][j - 1] == 1 or M[i + 1][j - 1] == 6):
                M[i][j] = 1
                M[i + 1][j - 1] = 3

                find = True
                cond = False
                detecDame(M)

    # une fois le coup trouvé, le son du pion s'active :
    p.set_volume(1)
    p.play()

    # On test si il y a encore des pions blancs et si les noirs on gagné : 
    wn = win_game_noir(M, 12)
    if wn == True:
        app.set_volume(0.6)
        app.play()
        messagebox.showinfo(title=None, message="Victoire des Noirs")
    else:
        pass


def topDroite(M, i, j, maxi1, maxj1, count, app, p):
    " Permet à une dame du bot de se déplacer sur une diagonale  "
    rnd = randint(1, count)

    if (M[maxi1 - 1][maxj1 + 1] == 2) & (M[maxi1 - 2][maxj1 + 2] == 1):
        rnd = count

    M[i][j] = 1
    M[i - rnd][j + rnd] = 8

    if (M[i - rnd - 1][j + rnd + 1] == 2) & ((M[i - rnd - 2][j + rnd + 2] == 1) or (M[i - rnd - 2][j + rnd + 2] == 6)):
        prisePionBOT(M, app, p)


def topLeft(M, i, j, maxi2, maxj2, count2, app, p):
    " Permet à une dame du bot de se déplacer sur une diagonale  "

    rnd = randint(1, count2)

    if (M[maxi2 - 1][maxj2 - 1] == 2) & (M[maxi2 - 2][maxj2 - 2] == 1):
        rnd = count2

    M[i][j] = 1
    M[i - rnd][j - rnd] = 8

    if (M[i - rnd - 1][j - rnd - 1] == 2) & ((M[i - rnd - 2][j - rnd - 2] == 1) or (M[i - rnd - 2][j - rnd - 2] == 6)):
        prisePionBOT(M, app, p)


def basLeft(M, i, j, maxi3, maxj3, count3, app, p):
    " Permet à une dame du bot de se déplacer sur une diagonale  "
    rnd = randint(1, count3)

    if (M[maxi3 + 1][maxj3 - 1] == 2) & (M[maxi3 + 2][maxj3 - 2] == 1):
        rnd = count3

    M[i][j] = 1
    M[i + rnd][j - rnd] = 8

    if (M[i + rnd + 1][j - rnd - 1] == 2) & ((M[i + rnd + 2][j - rnd - 2] == 1) or (M[i + rnd + 2][j - rnd - 2] == 6)):
        prisePionBOT(M, app, p)


def basDroite(M, i, j, maxi4, maxj4, count4, app, p):
    " Permet à une dame du bot de se déplacer sur une diagonale  "

    rnd = randint(1, count4)

    if (M[maxi4 + 1][maxj4 + 1] == 2) & (M[maxi4 + 2][maxj4 + 2] == 1):
        rnd = count4

    M[i][j] = 1
    M[i + rnd][j + rnd] = 8

    if (M[i + rnd + 1][j + rnd + 1] == 2) & ((M[i + rnd + 2][j + rnd + 2] == 1) or (M[i + rnd + 2][j + rnd + 2] == 6)):
        prisePionBOT(M, app, p)
